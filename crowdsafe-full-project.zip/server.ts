import express from 'express';
import { createServer as createViteServer } from 'vite';

interface MobileFramePayload {
  image?: string;
  detectedCount: number;
  density: number;
  velocity: number;
  losLevel: string;
  zoneId: string;
  timestamp: number;
  facingMode?: string;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON parser with sufficient limit for base64 camera frame snapshots
  app.use(express.json({ limit: '15mb' }));

  let latestMobileFrame: MobileFramePayload | null = null;
  let lastReceivedTime = 0;
  let sseClients: express.Response[] = [];

  // Mobile camera sends latest frame and AI telemetry
  app.post('/api/stream/frame', (req, res) => {
    const payload = req.body as MobileFramePayload;
    payload.timestamp = Date.now();
    latestMobileFrame = payload;
    lastReceivedTime = Date.now();

    // Broadcast frame to all listening dashboard desktop clients
    const sseData = `data: ${JSON.stringify(payload)}\n\n`;
    sseClients.forEach((client) => {
      try {
        client.write(sseData);
      } catch (e) {
        // client disconnected
      }
    });

    res.json({ success: true, timestamp: payload.timestamp });
  });

  // Desktop dashboard can fetch latest frame directly
  app.get('/api/stream/frame', (req, res) => {
    const isRecent = Date.now() - lastReceivedTime < 5000;
    if (isRecent && latestMobileFrame) {
      res.json({ active: true, ...latestMobileFrame });
    } else {
      res.json({ active: false });
    }
  });

  // Server-Sent Events (SSE) stream for real-time camera updates
  app.get('/api/stream/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    sseClients.push(res);

    // Send initial frame if available and recent
    if (latestMobileFrame && Date.now() - lastReceivedTime < 5000) {
      res.write(`data: ${JSON.stringify(latestMobileFrame)}\n\n`);
    }

    req.on('close', () => {
      sseClients = sseClients.filter((c) => c !== res);
    });
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', uptime: process.uptime() });
  });

  // Integrate Vite SPA middleware
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });

  app.use(vite.middlewares);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CrowdSafe Full-Stack Server running on port ${PORT}`);
  });
}

startServer();
