export type CrowdDensityLevel = 'low' | 'moderate' | 'high' | 'critical';

export type ZoneTrend = 'rising' | 'stable' | 'decreasing';

export type ZoneType = 'stage' | 'concourse' | 'plaza' | 'gate' | 'corridor' | 'lawn' | 'medical';

export interface Amenity {
  id: string;
  type: 'exit' | 'entrance' | 'first-aid' | 'water' | 'restroom' | 'accessible-ramp' | 'info';
  name: string;
  x: number; // percentage in SVG coordinate space 0..100
  y: number; // percentage in SVG coordinate space 0..100
  notes: string;
  status: 'open' | 'congested' | 'emergency-only';
  accessible: boolean;
}

export interface Zone {
  id: string;
  name: string;
  code: string;
  type: ZoneType;
  x: number;
  y: number;
  width: number;
  height: number;
  path?: string; // SVG path or polygon points
  currentOccupancy: number;
  licensedCapacity: number;
  densityPerM2: number;
  densityLevel: CrowdDensityLevel;
  trend: ZoneTrend;
  flowRatePerMin: number; // estimated people moving through per minute
  flowDirection: {
    angleDeg: number;
    label: string;
  };
  nearbyExits: string[];
  suggestedAction: string;
  accessibleRoute: boolean;
  notes: string;
}

export interface HourlyTrend {
  hour: string;
  occupancyPct: number;
  inflow: number;
  outflow: number;
  densityPerM2: number;
}

export type EventCategory = 
  | 'Job Fair & Skills'
  | 'Sports Festival'
  | 'Property & Business Expo'
  | 'Comedy & Entertainment'
  | 'Cultural & Music'
  | 'Handloom & Exhibition'
  | 'Theatre & Drama'
  | 'Music & Arts'
  | 'Sports Championship'
  | 'Civic & Cultural'
  | 'Tech Expo';

export interface EventData {
  id: string;
  title: string;
  venue: string;
  city: string;
  category: EventCategory;
  date: string;
  timeRange: string;
  status: 'In Progress' | 'Gates Opening' | 'Scheduled' | 'Concluding';
  timingStatus: 'ongoing' | 'upcoming';
  overallCrowdLevel: CrowdDensityLevel;
  totalCapacity: number;
  estimatedOccupancy: number;
  description: string;
  emergencyNotice: string;
  zones: Zone[];
  amenities: Amenity[];
  coordinates: {
    lat: number;
    lng: number;
  };
  hourlyTrends: HourlyTrend[];
  emergencyContacts: {
    venueControl: string;
    onSiteMedical: string;
    lostAssistance: string;
    assemblyPoint: string;
  };
  stewardTeams: {
    id: string;
    name: string;
    zoneId: string;
    lead: string;
    status: 'on-station' | 'dispatched' | 'standby';
  }[];
}

export type AlertSeverity = 'advisory' | 'moderate' | 'high' | 'critical';

export type AlertCategory = 
  | 'rising_density'
  | 'opposing_flows'
  | 'blocked_exit'
  | 'slow_movement'
  | 'capacity_threshold';

export type AlertStatus = 'active' | 'acknowledged' | 'assigned' | 'resolved';

export interface AlertNote {
  id: string;
  author: string;
  time: string;
  text: string;
}

export interface StatusTransition {
  status: AlertStatus;
  by: string;
  time: string;
  note?: string;
}

export interface Alert {
  id: string;
  eventId: string;
  zoneId: string;
  zoneName: string;
  severity: AlertSeverity;
  category: AlertCategory;
  title: string;
  observedChange: string;
  timestamp: string;
  confidence: string; // e.g. "Simulated Optical Cluster #04 (92% confidence)"
  sensorType: 'optical' | 'turnstile' | 'steward_report' | 'acoustic' | 'pressure';
  status: AlertStatus;
  assignedTo?: string;
  recommendedAction: string;
  internalNotes: AlertNote[];
  statusHistory: StatusTransition[];
}

export interface AppNotification {
  id: string;
  eventId?: string;
  zoneId?: string;
  alertId?: string;
  targetRole: 'all' | 'attendee' | 'manager';
  severity: 'info' | 'calm_guidance' | 'advisory' | 'urgent';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionLabel?: string;
}

export type UserRole = 'guest' | 'attendee' | 'manager';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  roleTitle: string;
  avatarInitials: string;
  badgeNumber?: string;
}

export interface UserSettings {
  stepFreePreferred: boolean;
  sensoryQuietAlerts: boolean;
  highContrast: boolean;
  reducedMotion: boolean;
  notificationSound: boolean;
  notificationVibrate: boolean;
  autoRefreshRate: number; // seconds
}

export interface ManagerThresholds {
  criticalDensityPerM2: number; // default 4.0
  highDensityPerM2: number;     // default 2.5
  slowFlowThreshold: number;    // default 15 ppl/min
  exitCongestionRatio: number;  // default 0.85 (85% capacity)
}

export interface UserLocation {
  active: boolean;
  isSimulated: boolean;
  lat?: number;
  lng?: number;
  mapX?: number; // 0..100 on venue map
  mapY?: number; // 0..100 on venue map
  nearestZoneId?: string;
  error?: string;
  permissionState: 'prompt' | 'granted' | 'denied' | 'unsupported';
}

export interface CalmedRoute {
  id: string;
  originZoneId: string;
  targetZoneId: string;
  pathZoneIds: string[];
  title: string;
  crowdLevel: CrowdDensityLevel;
  averageDensity: number;
  estimatedMinutes: number;
  isStepFree: boolean;
  instructions: string[];
  keySafetyTip: string;
}
