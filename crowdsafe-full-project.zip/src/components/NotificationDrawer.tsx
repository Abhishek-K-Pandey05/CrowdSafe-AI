import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Bell,
  CheckCheck,
  AlertTriangle,
  Info,
  HeartPulse,
  Compass,
  ArrowRight,
  Shield,
  Trash2,
} from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const {
    isNotificationDrawerOpen,
    setIsNotificationDrawerOpen,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    clearNotification,
    setCurrentView,
    setSelectedZoneId,
    setSelectedAlertId,
    isManager,
  } = useApp();

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  if (!isNotificationDrawerOpen) return null;

  const relevantNotifications = notifications.filter((n) => {
    if (n.targetRole === 'manager' && !isManager) return false;
    if (filter === 'unread') return !n.read;
    return true;
  });

  const handleAction = (n: typeof notifications[0]) => {
    markNotificationRead(n.id);
    setIsNotificationDrawerOpen(false);

    if (n.zoneId) {
      setSelectedZoneId(n.zoneId);
      setCurrentView('map');
    } else if (n.alertId && isManager) {
      setSelectedAlertId(n.alertId);
      setCurrentView('dashboard');
    } else {
      setCurrentView('attendee');
    }
  };

  const getSeverityIcon = (sev: string) => {
    switch (sev) {
      case 'urgent':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'advisory':
        return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      case 'calm_guidance':
        return <Compass className="w-4 h-4 text-emerald-600" />;
      default:
        return <Info className="w-4 h-4 text-sky-600" />;
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="notifications-title"
      className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end"
    >
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 id="notifications-title" className="text-base font-bold text-slate-900">
                Safety Notifications
              </h2>
              <p className="text-xs text-slate-500">Real-time calm crowd guidance & venue advisories</p>
            </div>
          </div>
          <button
            onClick={() => setIsNotificationDrawerOpen(false)}
            aria-label="Close notifications"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter bar & Mark all read */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 p-0.5 bg-slate-200/70 rounded-md">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                filter === 'unread' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Unread
            </button>
          </div>

          <button
            onClick={markAllNotificationsRead}
            className="text-slate-600 hover:text-slate-900 flex items-center gap-1 font-medium transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Mark all read</span>
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {relevantNotifications.length === 0 ? (
            <div className="py-16 text-center text-slate-400">
              <CheckCheck className="w-10 h-10 mx-auto text-emerald-500/50 mb-2" />
              <p className="text-sm font-medium text-slate-700">All caught up</p>
              <p className="text-xs text-slate-500 mt-1">
                No {filter === 'unread' ? 'unread' : 'active'} notifications for your current role.
              </p>
            </div>
          ) : (
            relevantNotifications.map((n) => (
              <div
                key={n.id}
                className={`p-3.5 rounded-lg border transition-all ${
                  n.read
                    ? 'bg-white border-slate-200 opacity-80'
                    : 'bg-emerald-50/40 border-emerald-200 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5 shrink-0">{getSeverityIcon(n.severity)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h3 className="text-xs font-semibold text-slate-900 leading-snug">{n.title}</h3>
                      <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{n.message}</p>

                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between">
                      {n.actionLabel ? (
                        <button
                          onClick={() => handleAction(n)}
                          className="text-xs font-medium text-emerald-700 hover:text-emerald-900 flex items-center gap-1 group"
                        >
                          <span>{n.actionLabel}</span>
                          <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400">Venue advisory</span>
                      )}

                      <div className="flex items-center gap-2">
                        {!n.read && (
                          <button
                            onClick={() => markNotificationRead(n.id)}
                            className="text-[11px] text-slate-500 hover:text-slate-800"
                          >
                            Dismiss
                          </button>
                        )}
                        <button
                          onClick={() => clearNotification(n.id)}
                          aria-label="Remove notification"
                          className="text-slate-400 hover:text-slate-600 p-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center">
          <p className="text-[11px] text-slate-500">
            Notifications are generated from event flow thresholds and steward observations.
          </p>
        </div>
      </div>
    </div>
  );
};
