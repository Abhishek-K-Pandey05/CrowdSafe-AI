import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertTriangle,
  TrendingUp,
  ShieldAlert,
  Flame,
  Clock,
  Activity,
  Users,
  DoorOpen,
  ArrowRight,
  CheckCircle2,
  Sliders,
  Sparkles,
  Info,
  Maximize2,
  RefreshCw,
  Zap,
  Volume2,
} from 'lucide-react';
import { EventData, Zone, CrowdDensityLevel } from '../types';

interface PredictiveCrowdAnalysisProps {
  event: EventData;
}

type TimeHorizon = 'now' | '15m' | '30m' | '60m';

interface HazardPrediction {
  id: string;
  hazardTitle: string;
  riskLevel: 'critical' | 'high' | 'moderate' | 'low';
  zoneAffected: string;
  triggerCondition: string;
  whatCanHappen: string;
  consequenceTimeline: string;
  preventativeAction: string;
  probabilityPct: number;
}

export const PredictiveCrowdAnalysis: React.FC<PredictiveCrowdAnalysisProps> = ({ event }) => {
  const { currentEvent, triggerSimulatedAlert } = useApp();

  const [timeHorizon, setTimeHorizon] = useState<TimeHorizon>('30m');
  const [simulateSurge, setSimulateSurge] = useState<boolean>(false);
  const [simulateGateRestriction, setSimulateGateRestriction] = useState<boolean>(false);
  const [appliedMitigations, setAppliedMitigations] = useState<{ [key: string]: boolean }>({});
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Compute projected metrics based on time horizon and simulated variables
  const projectionFactors = useMemo(() => {
    switch (timeHorizon) {
      case 'now':
        return { inflowMultiplier: 1.0, densityDelta: 0.0, label: 'Current Real-Time State' };
      case '15m':
        return {
          inflowMultiplier: simulateSurge ? 1.45 : 1.18,
          densityDelta: simulateSurge ? +0.6 : +0.25,
          label: '+15 Minutes (Next Arrival Window)',
        };
      case '30m':
        return {
          inflowMultiplier: simulateSurge ? 1.75 : 1.32,
          densityDelta: simulateSurge ? +1.2 : +0.55,
          label: '+30 Minutes (Projected Peak Surge)',
        };
      case '60m':
        return {
          inflowMultiplier: 0.9,
          densityDelta: -0.2,
          label: '+60 Minutes (Dispersal & Egress Phase)',
        };
    }
  }, [timeHorizon, simulateSurge]);

  // Projected overall attendance
  const baseOccupancy = event.estimatedOccupancy;
  const surgeAddon = simulateSurge ? 3200 : 0;
  const mitigationReduction = appliedMitigations['divert_hall_b'] ? 1800 : 0;
  const projectedOccupancy = Math.min(
    event.totalCapacity * 1.08,
    Math.round((baseOccupancy + (projectionFactors.inflowMultiplier - 1) * 4500 + surgeAddon) - mitigationReduction)
  );

  const projectedOccupancyPct = Math.round((projectedOccupancy / event.totalCapacity) * 100);

  // Identify high-risk zones under current projection
  const predictedZoneStates = useMemo(() => {
    return event.zones.map((z) => {
      let projectedDensity = z.densityPerM2 + projectionFactors.densityDelta;

      // Apply simulations
      if (simulateSurge && (z.type === 'gate' || z.type === 'concourse')) {
        projectedDensity += 0.7;
      }
      if (simulateGateRestriction && z.type === 'gate') {
        projectedDensity += 1.1;
      }

      // Apply mitigations
      if (appliedMitigations['meter_gate1'] && z.type === 'gate') {
        projectedDensity = Math.max(1.4, projectedDensity - 0.9);
      }
      if (appliedMitigations['divert_hall_b'] && z.code === 'HALL-A') {
        projectedDensity = Math.max(1.8, projectedDensity - 1.1);
      }
      if (appliedMitigations['open_perimeter_stanchions']) {
        projectedDensity = Math.max(1.2, projectedDensity - 0.5);
      }

      projectedDensity = Math.round(projectedDensity * 10) / 10;

      let level: CrowdDensityLevel = 'low';
      if (projectedDensity >= 3.8) level = 'critical';
      else if (projectedDensity >= 2.6) level = 'high';
      else if (projectedDensity >= 1.6) level = 'moderate';

      const projectedPeople = Math.round((z.licensedCapacity * (projectedDensity / 3.0)));

      return {
        ...z,
        projectedDensity,
        projectedLevel: level,
        projectedPeople: Math.min(z.licensedCapacity * 1.25, projectedPeople),
        capacityBreached: projectedDensity >= 3.6,
      };
    });
  }, [event.zones, projectionFactors, simulateSurge, simulateGateRestriction, appliedMitigations]);

  // Formulate Predictive Overcrowding Hazards ("What can happen")
  const hazardPredictions: HazardPrediction[] = useMemo(() => {
    const list: HazardPrediction[] = [];

    // 1. Compressive Shockwave / Physical Crush
    const criticalZone = predictedZoneStates.find((z) => z.projectedDensity >= 3.6);
    if (criticalZone) {
      list.push({
        id: 'hz-crush',
        hazardTitle: 'Severe Compressive Shockwave & Crowd Crush',
        riskLevel: 'critical',
        zoneAffected: criticalZone.name,
        triggerCondition: `Projected density reaching ${criticalZone.projectedDensity} ppl/m² (exceeds safe threshold of 3.0 ppl/m²)`,
        whatCanHappen:
          'Individuals lose independent bodily locomotion and become subject to involuntary fluid-like crowd forces. In continuous corridors, lateral shockwaves can cause falling, trampling, and compressive asphyxia without room to inhale.',
        consequenceTimeline:
          timeHorizon === 'now' ? 'Imminent in < 4 minutes' : 'Predicted at peak arrival in ~18–25 minutes',
        preventativeAction:
          'Immediately hold upstream arrival turnstiles. Deploy stewards to split queue lines into parallel holding pens and activate Hall B buffer space.',
        probabilityPct: criticalZone.projectedDensity >= 4.0 ? 92 : 78,
      });
    }

    // 2. Opposing Flow Gridlock & Velocity Collapse
    list.push({
      id: 'hz-opposing',
      hazardTitle: 'Opposing Flow Velocity Collapse (Turbulent Stagnation)',
      riskLevel: criticalZone ? 'high' : 'moderate',
      zoneAffected: event.zones[0]?.name || 'Main Aisle Concourse',
      triggerCondition: 'Candidates walking counter-directionally to exit doors without physical center barriers',
      whatCanHappen:
        'Walking velocity plummets below 0.25 m/s. Pedestrians become completely stationary; frustrated attendees begin shoving to push past counter-flows, rapidly escalating localized density from 2.2 to 3.8 ppl/m².',
      consequenceTimeline: 'Within 10 minutes of next transit shuttle arrival',
      preventativeAction:
        'Erect central stanchion tape to enforce strict one-way pedestrian lanes (Northbound entry, Southbound exit).',
      probabilityPct: 84,
    });

    // 3. Egress Starvation / Evacuation Clearance Failure
    list.push({
      id: 'hz-egress',
      hazardTitle: 'Emergency Egress Starvation & Evacuation Delay',
      riskLevel: simulateGateRestriction ? 'critical' : 'high',
      zoneAffected: 'All Emergency Egress Gates',
      triggerCondition: `${projectedOccupancy.toLocaleString()} attendees vs licensed venue capacity of ${event.totalCapacity.toLocaleString()} (${projectedOccupancyPct}% load)`,
      whatCanHappen:
        'In the event of a fire, sudden weather squall, or electrical outage, emergency egress clearance time stretches from standard 4.5 minutes to over 21.8 minutes. Exit vomitories experience choke point piling.',
      consequenceTimeline: 'Under any emergency evacuation alarm',
      preventativeAction:
        'Enforce 6-meter sterile clearance zones around all double-leaf exit portals. Ensure perimeter gate staff have verified unlocked latches.',
      probabilityPct: projectedOccupancyPct > 85 ? 88 : 55,
    });

    // 4. Nagpur Ambient Heat & Dehydration Distress
    list.push({
      id: 'hz-heat',
      hazardTitle: 'Thermal Stress & Heat Syncope (Mass Fainting)',
      riskLevel: 'moderate',
      zoneAffected: 'Unshaded Perimeter Queues (Gate 1 Plaza)',
      triggerCondition: 'Nagpur afternoon temperatures (33°C) combined with high metabolic body heat in packed pens',
      whatCanHappen:
        'Body heat trapped inside dense human clusters raises localized ambient temperature by +4.2°C. Attendees waiting in direct sun risk dehydration, heat exhaustion, dizziness, and fainting, causing sudden localized panic ripples.',
      consequenceTimeline: 'Throughout midday recruitment hours (12:00 – 15:30 IST)',
      preventativeAction:
        'Continuously circulate mobile ORS electrolyte stewards and ensure RO water dispensers are pressurized and free.',
      probabilityPct: 74,
    });

    return list;
  }, [predictedZoneStates, timeHorizon, simulateGateRestriction, projectedOccupancy, event, projectedOccupancyPct]);

  const handleApplyMitigation = (key: string, title: string) => {
    setAppliedMitigations((prev) => ({ ...prev, [key]: true }));
    setSuccessToast(`Proactive Mitigation Applied: "${title}". Predicted density safely reduced.`);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-0">
      {/* Section Header */}
      <div className="p-5 sm:p-6 bg-slate-900 text-white border-b border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span>AI Predictive Flow Engine · Hazard Anticipation</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            Predictive Crowd Density & Place Capacity Analysis
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Forecasting crowd bottlenecks and physical consequences for <strong>{event.title}</strong> at <strong>{event.venue}</strong>.
          </p>
        </div>

        {/* Time Horizon Selector */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Predictive Forecast:</span>
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700 text-xs">
            <button
              onClick={() => setTimeHorizon('now')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                timeHorizon === 'now' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              Current Live
            </button>
            <button
              onClick={() => setTimeHorizon('15m')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                timeHorizon === '15m' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              +15 Mins
            </button>
            <button
              onClick={() => setTimeHorizon('30m')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                timeHorizon === '30m' ? 'bg-red-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              +30 Mins (Peak)
            </button>
            <button
              onClick={() => setTimeHorizon('60m')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                timeHorizon === '60m' ? 'bg-sky-700 text-white shadow-xs' : 'text-slate-300 hover:text-white'
              }`}
            >
              +60 Mins (Egress)
            </button>
          </div>
        </div>
      </div>

      {/* Success Notification Banner */}
      {successToast && (
        <div className="bg-emerald-600 text-white text-xs font-semibold px-4 py-2.5 flex items-center justify-between animate-in fade-in duration-150">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast(null)} className="text-emerald-200 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Capacity & Place Headroom Stats Bar */}
      <div className="p-5 sm:p-6 bg-slate-50 border-b border-slate-200">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Licensed Venue Capacity */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold uppercase tracking-wider">Licensed Safe Capacity</span>
              <Users className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-2xl font-bold text-slate-900">
              {event.totalCapacity.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-500">Official Municipal Limit for {event.venue.split(',')[0]}</p>
          </div>

          {/* Projected Headroom Load */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold uppercase tracking-wider">Projected Attendance</span>
              <TrendingUp className="w-4 h-4 text-amber-500" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-slate-900">
                {projectedOccupancy.toLocaleString()}
              </span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded ${
                  projectedOccupancyPct >= 85
                    ? 'bg-red-100 text-red-800'
                    : projectedOccupancyPct >= 70
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {projectedOccupancyPct}% Capacity
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden mt-1">
              <div
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  projectedOccupancyPct >= 85
                    ? 'bg-red-600'
                    : projectedOccupancyPct >= 70
                    ? 'bg-amber-500'
                    : 'bg-emerald-600'
                }`}
                style={{ width: `${Math.min(100, projectedOccupancyPct)}%` }}
              />
            </div>
          </div>

          {/* Evacuation Clearance Time Projection */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold uppercase tracking-wider">Evacuation Clearance</span>
              <DoorOpen className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-bold text-slate-900">
              {projectedOccupancyPct >= 85 ? '16.8 mins' : '4.2 mins'}
            </div>
            <p className="text-[11px] text-slate-500">
              {projectedOccupancyPct >= 85
                ? '⚠️ Doorway queuing delays evacuation by +280%'
                : '✓ Unhindered perimeter clearance standard'}
            </p>
          </div>

          {/* Peak Choke Point Density */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold uppercase tracking-wider">Peak Sector Pressure</span>
              <Activity className="w-4 h-4 text-red-500" />
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-bold text-red-600">
                {Math.max(...predictedZoneStates.map((z) => z.projectedDensity))} ppl/m²
              </span>
              <span className="text-[11px] font-bold text-red-700 bg-red-50 px-1.5 py-0.5 rounded border border-red-200">
                CRITICAL THRESHOLD
              </span>
            </div>
            <p className="text-[11px] text-slate-500">Safety redline occurs at 4.0 ppl/m²</p>
          </div>
        </div>

        {/* Dynamic What-If Stress Testers */}
        <div className="mt-4 pt-4 border-t border-slate-200 flex flex-wrap items-center gap-3">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>Simulate Real-World Stress Tests:</span>
          </span>

          <button
            onClick={() => setSimulateSurge(!simulateSurge)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border flex items-center gap-1.5 ${
              simulateSurge
                ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Simulate 25% Inflow Transit Surge</span>
            {simulateSurge && <span className="ml-1 text-[10px] bg-amber-800 px-1 rounded">Active</span>}
          </button>

          <button
            onClick={() => setSimulateGateRestriction(!simulateGateRestriction)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border flex items-center gap-1.5 ${
              simulateGateRestriction
                ? 'bg-red-600 text-white border-red-700 shadow-xs'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Simulate Turnstile 50% Gate Stoppage</span>
            {simulateGateRestriction && <span className="ml-1 text-[10px] bg-red-800 px-1 rounded">Active</span>}
          </button>

          {(simulateSurge || simulateGateRestriction || Object.keys(appliedMitigations).length > 0) && (
            <button
              onClick={() => {
                setSimulateSurge(false);
                setSimulateGateRestriction(false);
                setAppliedMitigations({});
              }}
              className="text-xs text-slate-500 hover:text-slate-800 font-semibold underline ml-auto"
            >
              Reset Simulations
            </button>
          )}
        </div>
      </div>

      {/* Main Body: Predictive Hazards "What Can Happen" & Sector Forecast Grid */}
      <div className="p-5 sm:p-6 space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <h3 className="text-lg font-bold text-slate-900">
              Hazard Consequence Analysis: What Can Happen Under Overcrowding
            </h3>
          </div>
          <p className="text-xs text-slate-500">
            Based on empirical crowd dynamics, Fruin Level of Service (LOS F), and venue capacity modeling.
          </p>
        </div>

        {/* Hazard Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {hazardPredictions.map((hz) => (
            <div
              key={hz.id}
              className={`p-5 rounded-xl border flex flex-col justify-between space-y-4 transition-all ${
                hz.riskLevel === 'critical'
                  ? 'bg-red-50/70 border-red-200 ring-1 ring-red-300'
                  : hz.riskLevel === 'high'
                  ? 'bg-amber-50/70 border-amber-200'
                  : 'bg-blue-50/60 border-blue-200'
              }`}
            >
              <div className="space-y-2.5">
                {/* Header Tag */}
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded border ${
                      hz.riskLevel === 'critical'
                        ? 'bg-red-200 text-red-900 border-red-300'
                        : hz.riskLevel === 'high'
                        ? 'bg-amber-200 text-amber-900 border-amber-300'
                        : 'bg-blue-200 text-blue-900 border-blue-300'
                    }`}
                  >
                    ● {hz.riskLevel.toUpperCase()} RISK ({hz.probabilityPct}% Probability)
                  </span>
                  <span className="text-[11px] font-semibold text-slate-600">
                    Target: {hz.zoneAffected}
                  </span>
                </div>

                <h4 className="text-base font-bold text-slate-900 leading-snug">{hz.hazardTitle}</h4>

                {/* Trigger Condition */}
                <div className="text-xs text-slate-600 bg-white/70 p-2.5 rounded-lg border border-slate-200/80">
                  <strong className="text-slate-800">Trigger Condition:</strong> {hz.triggerCondition}
                </div>

                {/* What Can Happen */}
                <div className="text-xs text-slate-700 space-y-1">
                  <div className="font-bold text-red-950 flex items-center gap-1">
                    <span>⚠️ Physical Consequence:</span>
                  </div>
                  <p className="leading-relaxed bg-white/80 p-2.5 rounded-lg border border-slate-200/80">
                    {hz.whatCanHappen}
                  </p>
                </div>
              </div>

              {/* Preventative Action & Dispatch Button */}
              <div className="pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="text-[11px] text-slate-500 font-medium">
                  <strong>Timeline:</strong> {hz.consequenceTimeline}
                </div>

                {hz.id === 'hz-crush' && (
                  <button
                    onClick={() =>
                      handleApplyMitigation(
                        'meter_gate1',
                        'Gate 1 Turnstile Metering & Queue Stanchion Split'
                      )
                    }
                    disabled={appliedMitigations['meter_gate1']}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 ${
                      appliedMitigations['meter_gate1']
                        ? 'bg-emerald-600 text-white cursor-default'
                        : 'bg-red-600 hover:bg-red-700 text-white'
                    }`}
                  >
                    {appliedMitigations['meter_gate1'] ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Mitigation Deployed</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        <span>Deploy Metering Stanchions</span>
                      </>
                    )}
                  </button>
                )}

                {hz.id === 'hz-opposing' && (
                  <button
                    onClick={() =>
                      handleApplyMitigation(
                        'divert_hall_b',
                        'Divert Secondary Inflow to Hall B Buffer Area'
                      )
                    }
                    disabled={appliedMitigations['divert_hall_b']}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 ${
                      appliedMitigations['divert_hall_b']
                        ? 'bg-emerald-600 text-white cursor-default'
                        : 'bg-amber-600 hover:bg-amber-700 text-white'
                    }`}
                  >
                    {appliedMitigations['divert_hall_b'] ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Inflow Diverted</span>
                      </>
                    ) : (
                      <>
                        <ArrowRight className="w-3.5 h-3.5" />
                        <span>Divert Inflow to Hall B</span>
                      </>
                    )}
                  </button>
                )}

                {hz.id === 'hz-egress' && (
                  <button
                    onClick={() =>
                      handleApplyMitigation(
                        'open_perimeter_stanchions',
                        'Open 6m Sterile Egress Channels at Outer Gates'
                      )
                    }
                    disabled={appliedMitigations['open_perimeter_stanchions']}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 ${
                      appliedMitigations['open_perimeter_stanchions']
                        ? 'bg-emerald-600 text-white cursor-default'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    {appliedMitigations['open_perimeter_stanchions'] ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Egress Gates Cleared</span>
                      </>
                    ) : (
                      <>
                        <DoorOpen className="w-3.5 h-3.5" />
                        <span>Clear Egress Portals</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Zone-by-Zone Predicted Density Table */}
        <div className="pt-4 border-t border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900">
              Sector Density & Capacity Headroom Projections ({projectionFactors.label})
            </h4>
            <span className="text-xs text-slate-500 font-medium">
              Based on Fruin Crowd Velocity Curves
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Sector Code</th>
                  <th className="py-2.5 px-3">Sector Name</th>
                  <th className="py-2.5 px-3">Current Density</th>
                  <th className="py-2.5 px-3">Projected Density</th>
                  <th className="py-2.5 px-3">Projected Headroom Load</th>
                  <th className="py-2.5 px-3">Status Assessment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {predictedZoneStates.map((z) => {
                  const pct = Math.round((z.projectedPeople / z.licensedCapacity) * 100);
                  const isBreach = z.projectedDensity >= 3.6;

                  return (
                    <tr key={z.id} className={isBreach ? 'bg-red-50/50' : 'hover:bg-slate-50'}>
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{z.code}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{z.name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{z.densityPerM2} ppl/m²</td>
                      <td className="py-2.5 px-3 font-bold">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] ${
                            z.projectedDensity >= 3.8
                              ? 'bg-red-600 text-white'
                              : z.projectedDensity >= 2.6
                              ? 'bg-amber-500 text-white'
                              : 'bg-emerald-600 text-white'
                          }`}
                        >
                          {z.projectedDensity} ppl/m²
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-800 w-12">{pct}%</span>
                          <div className="w-20 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-1.5 rounded-full ${
                                pct >= 90 ? 'bg-red-600' : pct >= 75 ? 'bg-amber-500' : 'bg-emerald-500'
                              }`}
                              style={{ width: `${Math.min(100, pct)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-3">
                        {isBreach ? (
                          <span className="font-bold text-red-700 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-red-600" />
                            <span>Crush Danger Threshold</span>
                          </span>
                        ) : pct >= 75 ? (
                          <span className="font-semibold text-amber-700">Elevated Flow Pressure</span>
                        ) : (
                          <span className="font-semibold text-emerald-700">Stable Walking Flow</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
