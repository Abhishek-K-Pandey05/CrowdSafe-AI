import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Sliders, AlertTriangle, ShieldCheck, Check, RotateCcw, Info } from 'lucide-react';
import { INITIAL_THRESHOLDS } from '../data/mockEvents';

export const ThresholdsModal: React.FC = () => {
  const {
    isThresholdsModalOpen,
    setIsThresholdsModalOpen,
    thresholds,
    updateThresholds,
  } = useApp();

  const [criticalDensity, setCriticalDensity] = useState(thresholds.criticalDensityPerM2);
  const [highDensity, setHighDensity] = useState(thresholds.highDensityPerM2);
  const [slowFlow, setSlowFlow] = useState(thresholds.slowFlowThreshold);
  const [exitRatio, setExitRatio] = useState(thresholds.exitCongestionRatio);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isThresholdsModalOpen) return null;

  const handleSave = () => {
    updateThresholds({
      criticalDensityPerM2: Number(criticalDensity),
      highDensityPerM2: Number(highDensity),
      slowFlowThreshold: Number(slowFlow),
      exitCongestionRatio: Number(exitRatio),
    });
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      setIsThresholdsModalOpen(false);
    }, 900);
  };

  const handleReset = () => {
    setCriticalDensity(INITIAL_THRESHOLDS.criticalDensityPerM2);
    setHighDensity(INITIAL_THRESHOLDS.highDensityPerM2);
    setSlowFlow(INITIAL_THRESHOLDS.slowFlowThreshold);
    setExitRatio(INITIAL_THRESHOLDS.exitCongestionRatio);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="thresholds-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="relative bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center">
              <Sliders className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h2 id="thresholds-modal-title" className="text-base font-bold text-slate-900">
                Safety & Bottleneck Thresholds
              </h2>
              <p className="text-xs text-slate-500">Configure trigger rules for automated crowd risk alerts</p>
            </div>
          </div>
          <button
            onClick={() => setIsThresholdsModalOpen(false)}
            aria-label="Close thresholds settings"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Safety Engineering Advisory Banner */}
        <div className="my-4 p-3.5 bg-amber-50 rounded-lg border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold">Professional Safety Engineering Requirement</p>
            <p className="text-amber-800 text-[11px] leading-relaxed">
              These values calibrate automated alerts in the demo system. In real-world events, crowd thresholds must be established by certified crowd safety managers, local fire marshals, and licensed structural engineers under the UK Green Guide / NFPA 101 standards.
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4 py-2 text-xs">
          {/* Critical Density Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="font-semibold text-slate-800">
                Critical Density Trigger ({criticalDensity.toFixed(1)} persons/m²)
              </label>
              <span className="text-[11px] text-red-600 font-medium">Imminent crush hazard</span>
            </div>
            <input
              type="range"
              min="3.0"
              max="5.5"
              step="0.1"
              value={criticalDensity}
              onChange={(e) => setCriticalDensity(parseFloat(e.target.value))}
              className="w-full accent-red-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Triggers urgent intervention alerts when standing density restricts voluntary walking space.
            </p>
          </div>

          {/* High Density Warning */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="font-semibold text-slate-800">
                High Density Advisory ({highDensity.toFixed(1)} persons/m²)
              </label>
              <span className="text-[11px] text-amber-600 font-medium">Developing congestion</span>
            </div>
            <input
              type="range"
              min="1.8"
              max="3.2"
              step="0.1"
              value={highDensity}
              onChange={(e) => setHighDensity(parseFloat(e.target.value))}
              className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Warns stewards before peak friction occurs, allowing proactive rerouting.
            </p>
          </div>

          {/* Slow Flow Floor */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="font-semibold text-slate-800">
                Corridor Flow Floor ({slowFlow} persons / min)
              </label>
              <span className="text-[11px] text-sky-700 font-medium">Stall detection</span>
            </div>
            <input
              type="range"
              min="8"
              max="35"
              step="1"
              value={slowFlow}
              onChange={(e) => setSlowFlow(parseInt(e.target.value, 10))}
              className="w-full accent-sky-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Flags corridors when egress movement rate drops below normal walking velocity.
            </p>
          </div>

          {/* Exit Congestion Ratio */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="font-semibold text-slate-800">
                Gate Congestion Ratio ({Math.round(exitRatio * 100)}% capacity)
              </label>
              <span className="text-[11px] text-slate-600 font-medium">Egress clearance</span>
            </div>
            <input
              type="range"
              min="0.60"
              max="0.95"
              step="0.05"
              value={exitRatio}
              onChange={(e) => setExitRatio(parseFloat(e.target.value))}
              className="w-full accent-slate-800 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Flags gates when queue footprint encroaches on designated egress door sweep clearances.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1.5 font-medium"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Standards</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsThresholdsModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Applied</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Save Calibration</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
