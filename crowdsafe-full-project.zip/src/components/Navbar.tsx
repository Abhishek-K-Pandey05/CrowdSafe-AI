import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Shield,
  Bell,
  Settings,
  Menu,
  X,
  User,
  ShieldCheck,
  Compass,
  LayoutDashboard,
  LogOut,
  Radio,
  Sliders,
  MapPin,
  ChevronDown,
  Camera,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    currentUser,
    isManager,
    logout,
    openAuthModal,
    unreadNotificationCount,
    setIsNotificationDrawerOpen,
    setIsSettingsModalOpen,
    isSimulationActive,
    toggleSimulation,
    loginAsAttendee,
    loginAsManager,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const handleNavClick = (view: typeof currentView) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-md py-1 px-1.5"
              aria-label="CrowdSafe Home"
            >
              <div className="w-9 h-9 rounded-lg bg-emerald-700 flex items-center justify-center text-white shadow-sm">
                <Shield className="w-5 h-5 text-emerald-100" strokeWidth={2.2} />
              </div>
              <div>
                <span className="font-semibold text-lg text-slate-900 tracking-tight">CrowdSafe</span>
                <span className="hidden sm:inline-block ml-2 text-xs text-slate-500 font-medium">
                  Public Event Safety
                </span>
              </div>
            </button>

            {/* Simulation Active Pill */}
            <div className="hidden lg:flex items-center gap-1.5 pl-3 border-l border-slate-200 text-xs text-slate-500">
              <span className={`inline-block w-2 h-2 rounded-full ${isSimulationActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
              <button
                onClick={toggleSimulation}
                title="Toggle simulated event telemetry feed"
                className="hover:text-slate-800 underline underline-offset-2 decoration-slate-300 transition-colors"
              >
                {isSimulationActive ? 'Simulated Telemetry: Active' : 'Simulation: Paused'}
              </button>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1" aria-label="Main Navigation">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                currentView === 'home'
                  ? 'text-emerald-800 bg-emerald-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('events')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                currentView === 'events'
                  ? 'text-emerald-800 bg-emerald-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              Explore Events
            </button>
            <button
              onClick={() => handleNavClick('map')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                currentView === 'map'
                  ? 'text-emerald-800 bg-emerald-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              Venue Map
            </button>
            <button
              onClick={() => handleNavClick('attendee')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                currentView === 'attendee'
                  ? 'text-emerald-800 bg-emerald-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              Attendee Guide
            </button>
            <button
              onClick={() => handleNavClick('mobile-camera')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                currentView === 'mobile-camera'
                  ? 'text-emerald-800 bg-emerald-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-emerald-600" />
              <span>Mobile Cam</span>
            </button>

            {/* Manager Safety Dashboard Link */}
            {isManager ? (
              <button
                onClick={() => handleNavClick('dashboard')}
                className={`ml-1 px-3 py-1.5 text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  currentView === 'dashboard'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-100 hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-emerald-400" />
                <span>Safety Dashboard</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  loginAsManager();
                  setCurrentView('dashboard');
                }}
                title="Switch to Safety Manager view"
                className="ml-1 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors flex items-center gap-1 border border-slate-200"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
                <span>Manager Mode</span>
              </button>
            )}
          </nav>

          {/* Right Action Icons & User Dropdown */}
          <div className="flex items-center gap-2">
            {/* Notification Bell */}
            <button
              onClick={() => setIsNotificationDrawerOpen(true)}
              aria-label={`Notifications, ${unreadNotificationCount} unread`}
              className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-emerald-500"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white shadow-xs">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {/* Settings Button */}
            <button
              onClick={() => setIsSettingsModalOpen(true)}
              aria-label="Application Settings & Accessibility"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-emerald-500"
            >
              <Settings className="w-5 h-5" />
            </button>

            {/* Profile / Sign In Dropdown */}
            <div className="relative">
              {currentUser ? (
                <div className="relative">
                  <button
                    onClick={() => setProfileDropdownOpen((prev) => !prev)}
                    className="flex items-center gap-2 py-1 px-2 rounded-lg hover:bg-slate-100 transition-colors focus-visible:ring-2 focus-visible:ring-emerald-500"
                    aria-expanded={profileDropdownOpen}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-xs ${
                        isManager ? 'bg-slate-800' : 'bg-emerald-600'
                      }`}
                    >
                      {currentUser.avatarInitials}
                    </div>
                    <div className="hidden lg:block text-left text-xs leading-tight">
                      <p className="font-semibold text-slate-800 truncate max-w-[110px]">{currentUser.name}</p>
                      <p className="text-slate-500 capitalize">{isManager ? 'Safety Manager' : 'Attendee'}</p>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  {/* Profile Dropdown Menu */}
                  {profileDropdownOpen && (
                    <div
                      className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
                      onClick={() => setProfileDropdownOpen(false)}
                    >
                      <div className="px-4 py-2 border-b border-slate-100">
                        <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Current Session</p>
                        <p className="font-semibold text-sm text-slate-900 truncate mt-0.5">{currentUser.name}</p>
                        <p className="text-xs text-slate-500 truncate">{currentUser.email}</p>
                        <p className="text-[11px] text-emerald-700 bg-emerald-50 inline-block px-1.5 py-0.5 rounded mt-1.5 font-medium">
                          {currentUser.roleTitle}
                        </p>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={loginAsAttendee}
                          className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <User className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Switch to Attendee (Maya Chen)</span>
                        </button>
                        <button
                          onClick={() => {
                            loginAsManager();
                            setCurrentView('dashboard');
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-slate-800" />
                          <span>Switch to Safety Manager (Marcus Vance)</span>
                        </button>
                      </div>

                      <div className="border-t border-slate-100 pt-1">
                        <button
                          onClick={logout}
                          className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out (Return to Guest)</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => openAuthModal('attendee')}
                  className="px-3 py-1.5 text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors shadow-xs"
                >
                  Sign In
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              aria-label="Toggle Navigation Menu"
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-4 space-y-1">
          <button
            onClick={() => handleNavClick('home')}
            className={`w-full text-left px-3 py-2 text-base font-medium rounded-md ${
              currentView === 'home' ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('events')}
            className={`w-full text-left px-3 py-2 text-base font-medium rounded-md ${
              currentView === 'events' ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            Explore Events
          </button>
          <button
            onClick={() => handleNavClick('map')}
            className={`w-full text-left px-3 py-2 text-base font-medium rounded-md ${
              currentView === 'map' ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            Venue Map
          </button>
          <button
            onClick={() => handleNavClick('attendee')}
            className={`w-full text-left px-3 py-2 text-base font-medium rounded-md ${
              currentView === 'attendee' ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            Attendee Guide
          </button>
          <button
            onClick={() => handleNavClick('mobile-camera')}
            className={`w-full text-left px-3 py-2 text-base font-medium rounded-md flex items-center justify-between ${
              currentView === 'mobile-camera' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-900 font-semibold'
            }`}
          >
            <span className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-emerald-600" />
              <span>Mobile AI Camera</span>
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
              Live
            </span>
          </button>
          {isManager && (
            <button
              onClick={() => handleNavClick('dashboard')}
              className={`w-full text-left px-3 py-2 text-base font-medium rounded-md flex items-center justify-between ${
                currentView === 'dashboard' ? 'bg-slate-900 text-white' : 'bg-slate-800 text-slate-100'
              }`}
            >
              <span>Safety Manager Dashboard</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </button>
          )}

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Role: <strong className="text-slate-700">{currentUser ? currentUser.roleTitle : 'Guest'}</strong>
            </span>
            {!currentUser ? (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  openAuthModal('attendee');
                }}
                className="text-xs font-semibold text-emerald-700 underline"
              >
                Sign In
              </button>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                }}
                className="text-xs font-medium text-red-600 underline"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
