import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Sliders,
  Eye,
  Volume2,
  Accessibility,
  MapPin,
  Shield,
  Activity,
  Check,
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    settings,
    updateSettings,
    userLocation,
    stopSharingLocation,
    currentUser,
    isManager,
    setIsThresholdsModalOpen,
  } = useApp();

  if (!isSettingsModalOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="relative bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 id="settings-modal-title" className="text-base font-bold text-slate-900">
                Preferences & Accessibility
              </h2>
              <p className="text-xs text-slate-500">Configure wayfinding, notifications, and visual comfort</p>
            </div>
          </div>
          <button
            onClick={() => setIsSettingsModalOpen(false)}
            aria-label="Close settings"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-5 max-h-[75vh] overflow-y-auto pr-1">
          {/* Section 1: Accessibility & Routing */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Accessibility className="w-3.5 h-3.5 text-emerald-700" />
              <span>Wayfinding & Accessibility</span>
            </h3>

            <div className="space-y-2.5">
              <label className="flex items-start justify-between gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">
                    Prefer Step-Free & Accessible Pathways
                  </span>
                  <span className="text-[11px] text-slate-500 block leading-relaxed">
                    Prioritizes ramps, elevators, and wide corridors without curbs or lawn berm stairs during route calculation.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.stepFreePreferred}
                  onChange={(e) => updateSettings({ stepFreePreferred: e.target.checked })}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
              </label>

              <label className="flex items-start justify-between gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">
                    Sensory Quiet Zones Advisory
                  </span>
                  <span className="text-[11px] text-slate-500 block leading-relaxed">
                    Highlights shaded low-decibel respite areas (e.g. Shaded Groves) on your event map.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.sensoryQuietAlerts}
                  onChange={(e) => updateSettings({ sensoryQuietAlerts: e.target.checked })}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
              </label>
            </div>
          </div>

          {/* Section 2: Display & Motion */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-emerald-700" />
              <span>Display & Motion</span>
            </h3>

            <div className="space-y-2.5">
              <label className="flex items-start justify-between gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">
                    Reduced Motion Mode
                  </span>
                  <span className="text-[11px] text-slate-500 block leading-relaxed">
                    Disables background particle flows and animated vector pulse loops to minimize distraction.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.reducedMotion}
                  onChange={(e) => updateSettings({ reducedMotion: e.target.checked })}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
              </label>

              <label className="flex items-start justify-between gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">
                    High Contrast Map Accents
                  </span>
                  <span className="text-[11px] text-slate-500 block leading-relaxed">
                    Enhances boundary strokes and text labels for high sunlight legibility.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.highContrast}
                  onChange={(e) => updateSettings({ highContrast: e.target.checked })}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
              </label>
            </div>
          </div>

          {/* Section 3: Privacy & Location Sharing */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-700" />
              <span>Privacy & Geolocation</span>
            </h3>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">
                  Location Sharing: {userLocation.active ? (userLocation.isSimulated ? 'Simulated Pin' : 'Active GPS') : 'Off'}
                </span>
                {userLocation.active && (
                  <button
                    onClick={stopSharingLocation}
                    className="text-xs text-red-600 hover:text-red-800 font-medium underline"
                  >
                    Stop Sharing Pin
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                CrowdSafe processes your position only inside this browser session to show nearest exits and amenities. We never upload, log, or track your identity to external servers.
              </p>
            </div>
          </div>

          {/* Section 4: Manager Safety Controls (if signed in as manager) */}
          {isManager && (
            <div className="pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-semibold text-slate-900">Safety Thresholds Configuration</h3>
                  <p className="text-[11px] text-slate-500">Fine-tune critical density limits and warning flow rates</p>
                </div>
                <button
                  onClick={() => {
                    setIsSettingsModalOpen(false);
                    setIsThresholdsModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-slate-900 text-white rounded text-xs font-medium hover:bg-slate-800 transition-colors"
                >
                  Configure Limits
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => setIsSettingsModalOpen(false)}
            className="px-4 py-2 bg-emerald-700 text-white text-xs font-medium rounded-md hover:bg-emerald-800 shadow-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
