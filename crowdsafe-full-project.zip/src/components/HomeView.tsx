import React from 'react';
import { useApp } from '../context/AppContext';
import { GoogleMapsView } from './GoogleMapsView';
import {
  Shield,
  Compass,
  LayoutDashboard,
  Users,
  Footprints,
  Eye,
  CheckCircle2,
  Bell,
  ArrowRight,
  ShieldCheck,
  HeartPulse,
  Droplets,
  AlertTriangle,
  Clock,
  Sparkles,
  MapPin,
  Calendar,
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    setCurrentView,
    events,
    setSelectedEventId,
    openAuthModal,
    notifications,
    setIsNotificationDrawerOpen,
    unreadNotificationCount,
    loginAsAttendee,
    loginAsManager,
  } = useApp();

  const ongoingEvents = events.filter((e) => e.timingStatus === 'ongoing');
  const upcomingEvents = events.filter((e) => e.timingStatus === 'upcoming');

  return (
    <div className="relative min-h-screen space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative pt-12 pb-14 md:pt-16 md:pb-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            {/* Tagline kicker */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold mb-6">
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
              <span>Nagpur Public Event Safety & Flow Intelligence</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Calm, proactive safety for large public gatherings.
            </h1>

            {/* Supporting Description */}
            <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              CrowdSafe helps event attendees move with confidence and enables safety teams to anticipate choke points early. Monitoring live crowd dynamics at Symbiosis Skill Development Centre, Dhanwate National College, and venues across Nagpur.
            </p>

            {/* Safety-Focused Quote */}
            <div className="mt-6 pl-4 border-l-4 border-emerald-600 italic text-sm sm:text-base text-slate-700 bg-emerald-50/50 py-2.5 pr-4 rounded-r-lg">
              “The safest event is one where risks are seen early and people can move freely.”
            </div>

            {/* Primary Action Buttons */}
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => setCurrentView('events')}
                className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-lg shadow-sm transition-all flex items-center gap-2 group"
              >
                <span>Explore Events & Google Map</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={() => {
                  loginAsAttendee();
                  setCurrentView('attendee');
                }}
                className="px-5 py-3 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <Users className="w-4 h-4 text-emerald-600" />
                <span>Attendee Entry</span>
              </button>

              <button
                onClick={() => {
                  loginAsManager();
                  setCurrentView('dashboard');
                }}
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4 text-emerald-400" />
                <span>Event Manager Login</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Notifications Area Card & Real-time Live Signal Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="relative w-9 h-9 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-700">
                <Bell className="w-5 h-5" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white shadow-xs">
                    {unreadNotificationCount}
                  </span>
                )}
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Recent Venue Safety Notifications
                </h2>
                <p className="text-xs text-slate-500">
                  Real-time flow advisories from Rojgar Mahakumbh & Nagpur event control
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsNotificationDrawerOpen(true)}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
            >
              <span>View All Notifications ({notifications.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Sample Notifications Grid */}
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {notifications.slice(0, 2).map((n) => (
              <div
                key={n.id}
                className="p-3.5 rounded-lg bg-slate-50 border border-slate-200/80 hover:border-emerald-200 transition-colors flex items-start gap-3 text-xs"
              >
                <div className="mt-0.5 shrink-0">
                  {n.severity === 'calm_guidance' ? (
                    <Compass className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 truncate">{n.title}</span>
                    <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp}</span>
                  </div>
                  <p className="text-slate-600 mt-1 line-clamp-2 leading-relaxed">{n.message}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Google Map of All Event Locations Across Nagpur */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>Google Map Overview</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              Event Locations on Google Map
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
              Locating all 7 ongoing and upcoming event venues throughout Nagpur
            </p>
          </div>
          <button
            onClick={() => setCurrentView('events')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 shrink-0"
          >
            <span>Full Directory & Safety Filters</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <GoogleMapsView showHeader={false} height="h-[440px] sm:h-[500px]" />
      </section>

      {/* SECTION 1: ONGOING EVENTS (LIVE TODAY) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
        <div className="flex items-center justify-between pb-2 border-b-2 border-red-500">
          <div className="flex items-center gap-2.5">
            <span className="w-3 h-3 rounded-full bg-red-600 animate-ping inline-block" />
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Ongoing Events (Live Today · 29 September 2026)
            </h2>
          </div>
          <span className="text-xs font-bold text-red-700 bg-red-50 px-2.5 py-1 rounded border border-red-200">
            {ongoingEvents.length} Active in Nagpur
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {ongoingEvents.map((evt) => {
            const occupancyPct = Math.round((evt.estimatedOccupancy / evt.totalCapacity) * 100);

            return (
              <div
                key={evt.id}
                className="bg-white rounded-xl border border-red-200 ring-1 ring-red-100 p-5 sm:p-6 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                    <span className="font-bold text-red-800 bg-red-100 px-2 py-0.5 rounded uppercase text-[10px]">
                      ● LIVE TODAY
                    </span>
                    <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      {evt.category}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900">{evt.title}</h3>
                  <p className="text-xs font-medium text-slate-700 mt-1 flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{evt.venue}</span>
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">{evt.date} · {evt.timeRange}</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-600">Current Attendance:</span>
                      <span className="font-semibold text-slate-900">
                        {evt.estimatedOccupancy.toLocaleString()} / {evt.totalCapacity.toLocaleString()} ({occupancyPct}%)
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full ${
                          occupancyPct > 80 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${occupancyPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                  <button
                    onClick={() => {
                      setSelectedEventId(evt.id);
                      setCurrentView('map');
                    }}
                    className="flex-1 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors text-center"
                  >
                    View Venue Safety Map
                  </button>
                  <button
                    onClick={() => {
                      setSelectedEventId(evt.id);
                      setCurrentView('attendee');
                    }}
                    className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md transition-colors"
                  >
                    Attendee Guide
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 2: UPCOMING EVENTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
        <div className="flex items-center justify-between pb-2 border-b-2 border-sky-600">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-5 h-5 text-sky-600" />
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Upcoming Events (Nagpur Scheduled)
            </h2>
          </div>
          <span className="text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded border border-sky-200">
            {upcomingEvents.length} Scheduled
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingEvents.map((evt) => {
            return (
              <div
                key={evt.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                    <span className="font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded uppercase text-[10px]">
                      ○ UPCOMING
                    </span>
                    <span className="font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      {evt.category}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">{evt.title}</h3>
                  <p className="text-xs text-slate-600 mt-1 flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span>{evt.venue}</span>
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">{evt.date} · {evt.timeRange}</p>

                  <p className="mt-3 text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {evt.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setSelectedEventId(evt.id);
                      setCurrentView('map');
                    }}
                    className="flex-1 py-1.5 px-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-md shadow-xs transition-colors text-center"
                  >
                    Venue Layout
                  </button>
                  <button
                    onClick={() => {
                      setSelectedEventId(evt.id);
                      setCurrentView('attendee');
                    }}
                    className="py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium rounded-md transition-colors"
                  >
                    Guide
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4 Foundational Principles */}
      <section className="bg-slate-50 border-y border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              4 Pillars of Proactive Crowd Care
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Transforming event management from reactive crisis response into gentle, continuous flow orchestration.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">1</div>
              <h3 className="font-bold text-slate-900 text-sm">Early Bottleneck Anticipation</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Flags opposing flow collisions and velocity stalls at 2.5 persons/m² before physical compression or crush conditions can form.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">2</div>
              <h3 className="font-bold text-slate-900 text-sm">Calm, Dignified Navigation</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Provides attendees with step-free alternate routes and shaded bypass pathways rather than alarmist warnings or sudden gate closures.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">3</div>
              <h3 className="font-bold text-slate-900 text-sm">Multi-Source Verification</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Cross-references optical density telemetry, turnstile inflow rates, and on-ground steward reports to eliminate false alarms.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">4</div>
              <h3 className="font-bold text-slate-900 text-sm">Respectful Privacy Safeguards</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Zero facial recognition or personal background tracking. Browser location operates entirely on your local device with instant opt-out.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
