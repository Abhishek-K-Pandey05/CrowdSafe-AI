import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { InteractiveMap } from './InteractiveMap';
import {
  Compass,
  MapPin,
  HeartPulse,
  Droplets,
  DoorOpen,
  Accessibility,
  ArrowRight,
  Shield,
  PhoneCall,
  Sliders,
  CheckCircle2,
  Info,
  Footprints,
  Clock,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';

export const AttendeeView: React.FC = () => {
  const {
    currentEvent,
    userLocation,
    requestUserLocation,
    stopSharingLocation,
    setIsRouteModalOpen,
    setIsSettingsModalOpen,
    notifications,
    settings,
  } = useApp();

  const [activeAmenityCategory, setActiveAmenityCategory] = useState<'all' | 'water' | 'first-aid' | 'restroom' | 'exit'>('all');

  const filteredAmenities = currentEvent.amenities.filter((am) => {
    if (activeAmenityCategory === 'all') return true;
    return am.type === activeAmenityCategory;
  });

  const attendeeNotifications = notifications.filter(
    (n) => n.targetRole === 'all' || n.targetRole === 'attendee'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Event Header Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
            <Shield className="w-4 h-4 text-emerald-600" />
            <span>Attendee Safety & Wayfinding Companion</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {currentEvent.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            {currentEvent.venue} · {currentEvent.city} · {currentEvent.date}
          </p>
        </div>

        {/* Action Buttons: Calmed Route & Preferences */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsRouteModalOpen(true)}
            className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Compass className="w-4 h-4" />
            <span>Find a Less-Crowded Route</span>
          </button>
          <button
            onClick={() => setIsSettingsModalOpen(true)}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Sliders className="w-4 h-4 text-slate-500" />
            <span>Preferences</span>
          </button>
        </div>
      </div>

      {/* Official Emergency Announcement Banner */}
      <div className="p-4 bg-emerald-950 text-white rounded-xl shadow-md border border-emerald-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2 bg-emerald-800 rounded-lg shrink-0">
            <HeartPulse className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <p className="font-bold text-emerald-100">Live Safety Protocol & Steward Advice</p>
            <p className="text-emerald-300 text-xs mt-0.5">{currentEvent.emergencyNotice}</p>
          </div>
        </div>
        <div className="shrink-0 text-right sm:text-right">
          <span className="inline-block text-[11px] font-mono text-emerald-300 bg-emerald-900/60 px-2 py-1 rounded">
            Emergency Desk: {currentEvent.emergencyContacts.venueControl}
          </span>
        </div>
      </div>

      {/* Main Map Viewer & Zone Status */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Venue Flow & Amenity Map</h2>
            <p className="text-xs text-slate-500">
              Interactive map with live simulated density, safe exits, and hydration points
            </p>
          </div>
          <span className="text-xs text-slate-500 font-medium">Tap any zone for exit tips</span>
        </div>

        {/* Map Component */}
        <InteractiveMap interactive={true} compact={false} showZonePanel={true} />
      </div>

      {/* Grid: Calm Safety Notifications + Nearby Amenities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 spans): Amenities Directory */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Nearby Safe Amenities</h3>
                <p className="text-xs text-slate-500">
                  Potable water, accessible restrooms, first aid, and open egress gates
                </p>
              </div>

              {/* Amenity Filter Buttons */}
              <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg text-xs overflow-x-auto">
                <button
                  onClick={() => setActiveAmenityCategory('all')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors ${
                    activeAmenityCategory === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setActiveAmenityCategory('water')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors ${
                    activeAmenityCategory === 'water'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Water
                </button>
                <button
                  onClick={() => setActiveAmenityCategory('first-aid')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors ${
                    activeAmenityCategory === 'first-aid'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  First Aid
                </button>
                <button
                  onClick={() => setActiveAmenityCategory('restroom')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors ${
                    activeAmenityCategory === 'restroom'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Restrooms
                </button>
                <button
                  onClick={() => setActiveAmenityCategory('exit')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors ${
                    activeAmenityCategory === 'exit'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Exits
                </button>
              </div>
            </div>

            {/* Amenity Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredAmenities.map((am) => (
                <div
                  key={am.id}
                  className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-colors flex items-start gap-3 text-xs"
                >
                  <div className="p-2 rounded-md bg-white border border-slate-200 text-slate-700 shrink-0">
                    {am.type === 'water' && <Droplets className="w-4 h-4 text-sky-600" />}
                    {am.type === 'first-aid' && <HeartPulse className="w-4 h-4 text-red-600" />}
                    {am.type === 'exit' && <DoorOpen className="w-4 h-4 text-emerald-600" />}
                    {am.type === 'restroom' && <span className="font-bold text-[10px] text-indigo-700">WC</span>}
                    {am.type === 'accessible-ramp' && <Accessibility className="w-4 h-4 text-violet-700" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 truncate">{am.name}</h4>
                      <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded capitalize">
                        {am.status}
                      </span>
                    </div>
                    <p className="text-slate-600 mt-1 line-clamp-2 leading-relaxed">{am.notes}</p>
                    {am.accessible && (
                      <span className="inline-flex items-center gap-1 text-[10px] text-violet-700 mt-2 font-medium">
                        <Accessibility className="w-3 h-3" />
                        <span>Step-free accessible</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Calm Notifications & Emergency Info */}
        <div className="space-y-4">
          {/* Notifications Card */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Event Flow Advisories</h3>
              <span className="text-xs text-slate-400 font-mono">Calm Tone</span>
            </div>

            <div className="space-y-3">
              {attendeeNotifications.slice(0, 3).map((n) => (
                <div
                  key={n.id}
                  className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-100 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-emerald-950">{n.title}</span>
                    <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">{n.message}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Emergency On-Site Directory Card */}
          <div className="bg-slate-900 text-slate-200 rounded-xl p-5 shadow-xs space-y-3.5 border border-slate-800 text-xs">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-emerald-400" />
              <span>On-Site Emergency Contacts</span>
            </h3>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Venue Dispatch:</span>
                <span className="font-mono text-white">{currentEvent.emergencyContacts.venueControl}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">On-Site Paramedics:</span>
                <span className="font-mono text-white">{currentEvent.emergencyContacts.onSiteMedical}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Information & Lost Persons:</span>
                <span className="font-mono text-white">{currentEvent.emergencyContacts.lostAssistance}</span>
              </div>
              <div className="pt-1">
                <span className="text-slate-400 block mb-0.5">Primary Assembly Field:</span>
                <span className="font-semibold text-emerald-300">
                  {currentEvent.emergencyContacts.assemblyPoint}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 pt-2 border-t border-slate-800 leading-relaxed">
              If instructed to evacuate, walk calmly toward illuminated exit signs. Keep walkways clear for first responder access.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
