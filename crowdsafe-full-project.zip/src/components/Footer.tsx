import React from 'react';
import { Shield, AlertTriangle, HeartPulse, Info, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { setCurrentView, openAuthModal, isManager } = useApp();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 mt-auto z-10">
      {/* Official Safety Guidance Banner */}
      <div className="bg-emerald-950/70 border-b border-emerald-900/60 py-3.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm text-emerald-200">
          <div className="flex items-center gap-2.5">
            <HeartPulse className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong>Official On-Site Guidance:</strong> In any event evacuation or safety scenario, always follow directions from trained venue stewards and official public address announcements.
            </span>
          </div>
          <span className="text-emerald-400/80 text-xs shrink-0">
            Venue Emergency Call: 911 / Direct Control Link
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Column 1: Brand & Philosophy */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white">
                <Shield className="w-4 h-4" />
              </div>
              <span className="font-semibold text-white text-base">CrowdSafe</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              CrowdSafe empowers event attendees and professional safety coordinators to spot developing density choke points, maintain free-flowing egress corridors, and ensure dignity and safety across large public gatherings.
            </p>
            <div className="flex items-start gap-2 pt-2 text-[11px] text-amber-300/90 bg-amber-950/40 p-2.5 rounded border border-amber-900/40 max-w-md">
              <Info className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <span>
                <strong>Demo Simulation Notice:</strong> All crowd densities, sensor feeds, GPS locations, and alert queues in this prototype are generated demo simulations for system verification.
              </span>
            </div>
          </div>

          {/* Column 2: Navigation */}
          <div>
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">Navigation</h3>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => setCurrentView('home')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Home Overview
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('events')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Event Directory
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('map')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Interactive Venue Map
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('attendee')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Attendee Companion & Calmed Routes
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (isManager) {
                      setCurrentView('dashboard');
                    } else {
                      openAuthModal('manager');
                    }
                  }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Safety Operations Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Privacy & Ethics */}
          <div>
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">Privacy & Trust</h3>
            <ul className="space-y-2 text-xs text-slate-400 leading-relaxed">
              <li>Zero personal telemetry tracking</li>
              <li>Local-only browser geolocation</li>
              <li>Non-surveillance aggregate density</li>
              <li>Accessible step-free wayfinding</li>
              <li>Decision support for trained safety crews</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© 2026 CrowdSafe Initiative. Human-centered crowd flow & event resilience.</p>
          <div className="flex items-center gap-4 text-xs">
            <span>Client-side verification preview</span>
            <span>·</span>
            <span>WCAG AA Contrast Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
