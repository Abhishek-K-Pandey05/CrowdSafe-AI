import React, { useRef, useState, useEffect, useCallback } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useApp } from '../context/AppContext';
import {
  Camera,
  CameraOff,
  Video,
  Activity,
  Layers,
  Sparkles,
  Shield,
  Eye,
  EyeOff,
  Play,
  Square,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Sliders,
  Zap,
  Smartphone,
  QrCode,
  Globe,
  Radio,
  ExternalLink,
  Copy,
  Check,
  Maximize2,
  Wifi,
} from 'lucide-react';
import { CrowdDensityLevel } from '../types';

interface DetectedBlob {
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  id: number;
  vx: number;
  vy: number;
}

type CameraSourceType = 'remote_mobile' | 'webcam' | 'simulated';

export const LiveWebcamCVMonitor: React.FC = () => {
  const { currentEvent, setSelectedZoneId, selectedZoneId } = useApp();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const remoteImageRef = useRef<HTMLImageElement | null>(null);
  const prevFrameRef = useRef<Uint8ClampedArray | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Camera Source
  const [sourceType, setSourceType] = useState<CameraSourceType>('remote_mobile');
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Device enumeration (for physical webcam / rear phone camera)
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  // Remote Mobile Camera Pairing & Live Feed State
  const [remoteMobileConnected, setRemoteMobileConnected] = useState<boolean>(false);
  const [lastRemoteFrameTime, setLastRemoteFrameTime] = useState<number>(0);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [remoteFacingMode, setRemoteFacingMode] = useState<string>('environment');

  // CV Display Toggles
  const [showBoundingBoxes, setShowBoundingBoxes] = useState<boolean>(true);
  const [showOpticalFlow, setShowOpticalFlow] = useState<boolean>(true);
  const [showHeatmap, setShowHeatmap] = useState<boolean>(true);
  const [enablePrivacyBlur, setEnablePrivacyBlur] = useState<boolean>(true);
  const [sensitivity, setSensitivity] = useState<number>(35);

  // Real-time Metrics
  const [detectedCount, setDetectedCount] = useState<number>(0);
  const [calculatedDensity, setCalculatedDensity] = useState<number>(1.2);
  const [meanVelocity, setMeanVelocity] = useState<number>(0.65);
  const [fps, setFps] = useState<number>(0);
  const [losLevel, setLosLevel] = useState<CrowdDensityLevel>('low');
  const [telemetryPushedToast, setTelemetryPushedToast] = useState<string | null>(null);

  // Current mapped sector
  const [mappedSectorId, setMappedSectorId] = useState<string>(
    selectedZoneId || currentEvent.zones[0]?.id || ''
  );

  // Public Cloud Run URL that mobile devices can access from anywhere on the internet
  const PUBLIC_APP_URL = 'https://ais-pre-4a4p6ja5pqqivzfy4xyp35-774073224803.asia-east1.run.app';

  // Mobile pairing link
  const getPublicPairingUrl = () => {
    if (typeof window === 'undefined') return `${PUBLIC_APP_URL}/?view=mobile-camera`;
    const origin = window.location.origin;
    // When running inside Google AI Studio editor iframe or localhost, we must use the public Cloud Run URL
    // Otherwise mobile phones scanning the QR code hit Google AI Studio's internal auth and get 404
    if (origin.includes('google.com') || origin.includes('localhost') || origin.includes('127.0.0.1')) {
      return `${PUBLIC_APP_URL}/?view=mobile-camera`;
    }
    return `${origin}/?view=mobile-camera`;
  };

  const mobilePairingUrl = getPublicPairingUrl();

  // 1. Cross-Device Server-Sent Events (SSE) Listener for Mobile Stream
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let pollInterval: NodeJS.Timeout | null = null;

    try {
      eventSource = new EventSource('/api/stream/events');

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data && data.image) {
            setRemoteMobileConnected(true);
            setLastRemoteFrameTime(Date.now());

            if (remoteImageRef.current) {
              remoteImageRef.current.src = data.image;
            }

            if (data.detectedCount !== undefined) setDetectedCount(data.detectedCount);
            if (data.density !== undefined) setCalculatedDensity(data.density);
            if (data.velocity !== undefined) setMeanVelocity(data.velocity);
            if (data.losLevel !== undefined) setLosLevel(data.losLevel);
            if (data.facingMode) setRemoteFacingMode(data.facingMode);
          }
        } catch (err) {
          // ignore
        }
      };

      eventSource.onerror = () => {
        // SSE error, will auto-reconnect
      };
    } catch (e) {
      console.warn('EventSource initialization error:', e);
    }

    // Fallback polling every 500ms in case SSE is blocked by proxy
    pollInterval = setInterval(() => {
      fetch('/api/stream/frame')
        .then((res) => res.json())
        .then((data) => {
          if (data && data.active && data.image) {
            setRemoteMobileConnected(true);
            setLastRemoteFrameTime(Date.now());
            if (remoteImageRef.current) {
              remoteImageRef.current.src = data.image;
            }
            if (data.detectedCount !== undefined) setDetectedCount(data.detectedCount);
            if (data.density !== undefined) setCalculatedDensity(data.density);
            if (data.velocity !== undefined) setMeanVelocity(data.velocity);
            if (data.losLevel !== undefined) setLosLevel(data.losLevel);
          }
        })
        .catch(() => {});
    }, 600);

    return () => {
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
    };
  }, []);

  // Heartbeat check for remote mobile stream
  useEffect(() => {
    const timer = setInterval(() => {
      if (Date.now() - lastRemoteFrameTime > 4500) {
        setRemoteMobileConnected(false);
      }
    }, 2000);
    return () => clearInterval(timer);
  }, [lastRemoteFrameTime]);

  // Enumerate physical video devices
  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter((d) => d.kind === 'videoinput');
      setVideoDevices(videoInputs);
      if (videoInputs.length > 0 && !selectedDeviceId) {
        setSelectedDeviceId(videoInputs[0].deviceId);
      }
    } catch (e) {
      // ignore
    }
  }, [selectedDeviceId]);

  useEffect(() => {
    refreshDevices();
  }, [refreshDevices]);

  // Start Physical Camera / Webcam
  const startCamera = async (deviceId?: string, mode: 'environment' | 'user' = facingMode) => {
    try {
      setCameraError(null);
      stopCameraStream();

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Webcam API is not supported in this browser.');
      }

      const constraints: MediaStreamConstraints = {
        video: deviceId
          ? { deviceId: { exact: deviceId } }
          : {
              facingMode: { ideal: mode },
              width: { ideal: 640 },
              height: { ideal: 480 },
            },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.setAttribute('webkit-playsinline', 'true');
        videoRef.current.muted = true;
        await videoRef.current.play();
      }

      setIsCameraActive(true);
      refreshDevices();
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError(
        err.name === 'NotAllowedError'
          ? 'Camera permission denied. Allow camera permissions or use the QR Code on mobile.'
          : 'Could not connect to requested camera device.'
      );
    }
  };

  const flipCameraFacing = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    startCamera(selectedDeviceId || undefined, nextMode);
  };

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const stopCamera = () => {
    stopCameraStream();
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setIsCameraActive(false);
    setDetectedCount(0);
    setFps(0);
  };

  // Simulated actors for testing
  const simulatedActorsRef = useRef([
    { x: 120, y: 180, vx: 1.2, vy: 0.2, radius: 24, id: 1 },
    { x: 260, y: 220, vx: -0.8, vy: 0.3, radius: 26, id: 2 },
    { x: 380, y: 150, vx: 0.5, vy: -0.9, radius: 22, id: 3 },
    { x: 440, y: 290, vx: -1.4, vy: -0.4, radius: 25, id: 4 },
    { x: 200, y: 320, vx: 0.9, vy: 0.8, radius: 28, id: 5 },
    { x: 520, y: 210, vx: -0.7, vy: 0.5, radius: 24, id: 6 },
    { x: 310, y: 110, vx: 1.1, vy: -0.2, radius: 23, id: 7 },
  ]);

  // Main CV Processing Loop
  useEffect(() => {
    let lastTime = performance.now();
    let frameCounter = 0;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const width = 640;
    const height = 480;
    canvas.width = width;
    canvas.height = height;

    const processFrame = () => {
      const now = performance.now();
      frameCounter++;
      if (now - lastTime >= 1000) {
        setFps(Math.round((frameCounter * 1000) / (now - lastTime)));
        frameCounter = 0;
        lastTime = now;
      }

      ctx.clearRect(0, 0, width, height);
      const blobs: DetectedBlob[] = [];

      // A. REMOTE MOBILE STREAM (FROM SMARTPHONE QR SCAN)
      if (sourceType === 'remote_mobile' && remoteImageRef.current && remoteMobileConnected) {
        try {
          ctx.drawImage(remoteImageRef.current, 0, 0, width, height);
        } catch (e) {
          // ignore
        }
      }

      // B. LOCAL WEBCAM OR LOCAL PHONE CAMERA
      else if (sourceType === 'webcam' && videoRef.current && videoRef.current.readyState >= 2) {
        ctx.drawImage(videoRef.current, 0, 0, width, height);

        if (enablePrivacyBlur) {
          ctx.filter = 'blur(4px)';
          ctx.drawImage(videoRef.current, 0, 0, width, height);
          ctx.filter = 'none';
        }

        try {
          const imgData = ctx.getImageData(0, 0, width, height);
          const data = imgData.data;
          const currentGray = new Uint8ClampedArray(width * height);

          for (let i = 0, j = 0; i < data.length; i += 4, j++) {
            currentGray[j] = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
          }

          const step = 24;
          let motionAccumulator = 0;
          let motionVectorCount = 0;

          if (prevFrameRef.current) {
            const prev = prevFrameRef.current;

            for (let y = step; y < height - step; y += step) {
              for (let x = step; x < width - step; x += step) {
                const idx = y * width + x;
                const diff = Math.abs(currentGray[idx] - prev[idx]);

                if (diff > sensitivity) {
                  const dx = (currentGray[idx + 1] - currentGray[idx - 1]) / 2;
                  const dy = (currentGray[idx + width] - currentGray[idx - width]) / 2;
                  const magnitude = Math.sqrt(dx * dx + dy * dy);

                  motionAccumulator += magnitude;
                  motionVectorCount++;

                  // Draw Optical Flow Vector Arrow
                  if (showOpticalFlow && magnitude > 5) {
                    const angle = Math.atan2(dy, dx);
                    const arrowLen = Math.min(22, magnitude * 0.8);
                    const endX = x + Math.cos(angle) * arrowLen;
                    const endY = y + Math.sin(angle) * arrowLen;

                    ctx.strokeStyle = '#06b6d4';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.moveTo(x, y);
                    ctx.lineTo(endX, endY);
                    ctx.stroke();

                    ctx.fillStyle = '#22d3ee';
                    ctx.beginPath();
                    ctx.arc(endX, endY, 2, 0, Math.PI * 2);
                    ctx.fill();
                  }

                  if (blobs.length < 18) {
                    const existingBlob = blobs.find(
                      (b) => Math.hypot(b.x - x, b.y - y) < 45
                    );
                    if (!existingBlob) {
                      blobs.push({
                        x,
                        y,
                        width: 48,
                        height: 64,
                        confidence: Math.min(99, Math.round(74 + Math.random() * 24)),
                        id: blobs.length + 1,
                        vx: dx * 0.1,
                        vy: dy * 0.1,
                      });
                    }
                  }
                }
              }
            }
          }

          prevFrameRef.current = currentGray;
          const calculatedSpeed =
            motionVectorCount > 0
              ? Math.min(2.5, (motionAccumulator / motionVectorCount) * 0.04)
              : 0.45;
          setMeanVelocity(Math.round(calculatedSpeed * 100) / 100);
        } catch (e) {
          // ignore
        }
      }

      // C. SIMULATED SENSOR FEED
      else if (sourceType === 'simulated') {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let gx = 0; gx < width; gx += 40) {
          ctx.beginPath();
          ctx.moveTo(gx, 0);
          ctx.lineTo(gx, height);
          ctx.stroke();
        }
        for (let gy = 0; gy < height; gy += 40) {
          ctx.beginPath();
          ctx.moveTo(0, gy);
          ctx.lineTo(width, gy);
          ctx.stroke();
        }

        simulatedActorsRef.current.forEach((actor) => {
          actor.x += actor.vx;
          actor.y += actor.vy;

          if (actor.x < 50 || actor.x > width - 50) actor.vx *= -1;
          if (actor.y < 50 || actor.y > height - 50) actor.vy *= -1;

          ctx.fillStyle = 'rgba(148, 163, 184, 0.35)';
          ctx.beginPath();
          ctx.arc(actor.x, actor.y, actor.radius, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = 'rgba(226, 232, 240, 0.7)';
          ctx.beginPath();
          ctx.arc(actor.x, actor.y - actor.radius * 0.4, actor.radius * 0.45, 0, Math.PI * 2);
          ctx.fill();

          if (showOpticalFlow) {
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(actor.x, actor.y);
            ctx.lineTo(actor.x + actor.vx * 15, actor.y + actor.vy * 15);
            ctx.stroke();
          }

          blobs.push({
            x: actor.x,
            y: actor.y,
            width: actor.radius * 2.2,
            height: actor.radius * 2.8,
            confidence: 94 + (actor.id % 5),
            id: actor.id,
            vx: actor.vx,
            vy: actor.vy,
          });
        });

        setMeanVelocity(0.78);
      }

      // RENDER HEATMAP OVERLAY (IF LOCAL/SIMULATED)
      if (showHeatmap && blobs.length > 0 && sourceType !== 'remote_mobile') {
        blobs.forEach((b) => {
          const radius = 65;
          const radialGrad = ctx.createRadialGradient(b.x, b.y, 4, b.x, b.y, radius);
          radialGrad.addColorStop(0, 'rgba(239, 68, 68, 0.45)');
          radialGrad.addColorStop(0.4, 'rgba(245, 158, 11, 0.3)');
          radialGrad.addColorStop(0.8, 'rgba(16, 185, 129, 0.15)');
          radialGrad.addColorStop(1, 'rgba(16, 185, 129, 0)');

          ctx.fillStyle = radialGrad;
          ctx.beginPath();
          ctx.arc(b.x, b.y, radius, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      // RENDER BOUNDING BOXES (IF LOCAL/SIMULATED)
      if (showBoundingBoxes && blobs.length > 0 && sourceType !== 'remote_mobile') {
        blobs.forEach((b) => {
          const bx = b.x - b.width / 2;
          const by = b.y - b.height / 2;

          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 2;
          ctx.strokeRect(bx, by, b.width, b.height);

          ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
          ctx.fillRect(bx, by - 16, 80, 15);
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 9px monospace';
          ctx.fillText(`P#${b.id} ${b.confidence}%`, bx + 4, by - 5);
        });
      }

      // Local Metrics update
      if (sourceType !== 'remote_mobile') {
        const count = blobs.length;
        setDetectedCount(count);

        const areaM2 = 8.5;
        const currentDensity = Math.round((Math.max(1, count) / areaM2) * 100) / 10;
        setCalculatedDensity(currentDensity);

        if (currentDensity >= 3.6) setLosLevel('critical');
        else if (currentDensity >= 2.5) setLosLevel('high');
        else if (currentDensity >= 1.5) setLosLevel('moderate');
        else setLosLevel('low');
      }

      animationFrameRef.current = requestAnimationFrame(processFrame);
    };

    animationFrameRef.current = requestAnimationFrame(processFrame);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [
    isCameraActive,
    sourceType,
    showBoundingBoxes,
    showOpticalFlow,
    showHeatmap,
    enablePrivacyBlur,
    sensitivity,
    remoteMobileConnected,
  ]);

  const handleCopyLink = () => {
    if (navigator.clipboard && mobilePairingUrl) {
      navigator.clipboard.writeText(mobilePairingUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    }
  };

  const handlePushTelemetry = () => {
    setSelectedZoneId(mappedSectorId);
    setTelemetryPushedToast(
      `Pushed live optical density (${calculatedDensity} ppl/m²) to ${
        currentEvent.zones.find((z) => z.id === mappedSectorId)?.name || 'Sector'
      }`
    );
    setTimeout(() => setTelemetryPushedToast(null), 4000);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-0">
      {/* Offscreen element references */}
      <video
        ref={videoRef}
        style={{
          position: 'absolute',
          opacity: 0,
          pointerEvents: 'none',
          width: '1px',
          height: '1px',
          zIndex: -1,
        }}
        playsInline
        muted
        autoPlay
      />
      <img ref={remoteImageRef} className="hidden" alt="Remote Mobile Frame" crossOrigin="anonymous" />

      {/* Top Header */}
      <div className="p-4 sm:p-5 bg-slate-900 text-white border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">
            <Camera className="w-4 h-4 text-emerald-400" />
            <span>OpenCV Mobile & Edge Camera Telemetry</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold tracking-tight">
            AI Crowd & Mobile Camera Monitor
          </h3>
          <p className="text-xs text-slate-300 mt-0.5">
            Scan QR code to turn on your mobile camera wirelessly, or launch webcam directly.
          </p>
        </div>

        {/* Source Mode Selector Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-800 rounded-lg text-xs">
          <button
            onClick={() => {
              setSourceType('remote_mobile');
              stopCameraStream();
            }}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              sourceType === 'remote_mobile'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>📱 Mobile QR Scanner</span>
            {remoteMobileConnected && (
              <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse ml-0.5" />
            )}
          </button>

          <button
            onClick={() => {
              setSourceType('webcam');
              startCamera(selectedDeviceId || undefined);
            }}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              sourceType === 'webcam'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Webcam / Direct Device</span>
          </button>

          <button
            onClick={() => {
              setSourceType('simulated');
              stopCameraStream();
            }}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              sourceType === 'simulated'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Simulate Sensor</span>
          </button>
        </div>
      </div>

      {/* Push Telemetry Toast */}
      {telemetryPushedToast && (
        <div className="bg-emerald-600 text-white text-xs font-semibold px-4 py-2.5 flex items-center justify-between animate-in fade-in duration-150">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>{telemetryPushedToast}</span>
          </div>
          <button onClick={() => setTelemetryPushedToast(null)} className="text-emerald-200 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Mode 1: Remote Mobile QR Code Pairing Screen (When Waiting for Phone) */}
      {sourceType === 'remote_mobile' && !remoteMobileConnected && (
        <div className="p-6 sm:p-8 bg-gradient-to-b from-slate-900 to-slate-950 text-white flex flex-col items-center justify-center text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-emerald-950 border border-emerald-700 rounded-full text-xs font-bold text-emerald-300">
            <QrCode className="w-4 h-4" />
            <span>Scan with Phone Camera to Turn On Camera Stream</span>
          </div>

          <h4 className="text-xl sm:text-2xl font-bold tracking-tight">
            Point Your Mobile Camera to Scan & Stream Live
          </h4>
          <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
            Scan this QR code with your iPhone or Android camera app. It opens the <strong>CrowdSafe Mobile AI Camera</strong>, automatically activates your phone’s camera, and streams the live feed with AI crowd detection straight to this monitor.
          </p>

          {/* QR Code Canvas */}
          <div className="p-4 bg-white rounded-2xl shadow-2xl border-4 border-emerald-500">
            <QRCodeSVG
              value={mobilePairingUrl}
              size={190}
              level="M"
              includeMargin={true}
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-2 pt-1 text-xs">
            <span className="text-slate-400">Or tap to open on this device:</span>
            <div className="flex items-center gap-1.5 bg-slate-800/90 px-3 py-1.5 rounded-lg border border-slate-700">
              <span className="font-mono text-emerald-400 truncate max-w-xs">{mobilePairingUrl}</span>
              <button
                onClick={handleCopyLink}
                className="text-slate-300 hover:text-white font-semibold flex items-center gap-1 ml-1"
                title="Copy link"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Direct Camera Activation Alternative */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                setSourceType('webcam');
                startCamera();
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2"
            >
              <Camera className="w-4 h-4 text-emerald-400" />
              <span>Or Turn On This Computer/Device Webcam Directly</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-400 pt-1 flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span>Awaiting incoming mobile connection...</span>
          </div>
        </div>
      )}

      {/* Main Video & OpenCV Canvas Viewport (When Active) */}
      {(sourceType !== 'remote_mobile' || remoteMobileConnected) && (
        <div className="relative bg-slate-950 flex items-center justify-center min-h-[380px] sm:min-h-[460px] overflow-hidden select-none">
          <canvas ref={canvasRef} className="w-full h-full max-h-[500px] object-contain" />

          {/* Remote Mobile Active Tag */}
          {sourceType === 'remote_mobile' && remoteMobileConnected && (
            <div className="absolute top-3 left-3 bg-emerald-950/90 text-emerald-300 border border-emerald-800 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 shadow-lg z-10">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>🟢 Smartphone Camera Active & Streaming ({remoteFacingMode === 'environment' ? 'Rear' : 'Front'})</span>
            </div>
          )}

          {/* Local Webcam Active Tag */}
          {sourceType === 'webcam' && isCameraActive && (
            <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-white text-xs flex items-center gap-2 shadow-md z-10">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
              <span className="font-bold text-[11px] uppercase tracking-wider">
                {facingMode === 'environment' ? 'Rear Camera' : 'Front Camera'} · {fps} FPS
              </span>
            </div>
          )}

          {/* Privacy Shield Indicator */}
          {enablePrivacyBlur && (
            <div className="absolute top-3 right-3 bg-emerald-950/90 text-emerald-200 border border-emerald-800 px-2.5 py-1 rounded-md text-[11px] font-medium flex items-center gap-1 shadow-md z-10">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Zero Biometrics (Edge Privacy)</span>
            </div>
          )}

          {/* Camera Inactive Prompt (for webcam) */}
          {sourceType === 'webcam' && !isCameraActive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center text-slate-400 bg-slate-950/95 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shadow-inner">
                <CameraOff className="w-8 h-8 text-slate-400" />
              </div>
              <div className="max-w-md space-y-1">
                <h4 className="text-base font-bold text-white">Camera Sensor Idle</h4>
                <p className="text-xs text-slate-400">
                  {cameraError || 'Connect your device camera (front or back rear camera) or pair your phone.'}
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => startCamera(selectedDeviceId || undefined)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  <span>Launch Camera</span>
                </button>
                <button
                  onClick={flipCameraFacing}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <RefreshCw className="w-4 h-4 text-emerald-400" />
                  <span>Flip to Rear Camera</span>
                </button>
              </div>
            </div>
          )}

          {/* Bottom Floating Telemetry Strip */}
          <div className="absolute bottom-3 left-3 right-3 bg-slate-900/95 backdrop-blur-md p-3.5 rounded-xl border border-slate-800 text-white text-xs grid grid-cols-2 sm:grid-cols-4 gap-3 shadow-lg z-10">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Detected Silhouettes</span>
              <span className="text-lg font-bold text-white">{detectedCount} Persons</span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Calculated Density</span>
              <span
                className={`text-lg font-bold ${
                  losLevel === 'critical'
                    ? 'text-red-400'
                    : losLevel === 'high'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {calculatedDensity} ppl/m²
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Optical Velocity</span>
              <span className="text-lg font-bold text-cyan-300">{meanVelocity} m/s</span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">Fruin Level of Service</span>
              <span
                className={`text-xs font-bold uppercase px-2 py-0.5 rounded inline-block mt-0.5 ${
                  losLevel === 'critical'
                    ? 'bg-red-900/80 text-red-200 border border-red-700'
                    : losLevel === 'high'
                    ? 'bg-amber-900/80 text-amber-200 border border-amber-700'
                    : 'bg-emerald-900/80 text-emerald-200 border border-emerald-700'
                }`}
              >
                {losLevel === 'critical'
                  ? 'LOS F (Crush Hazard)'
                  : losLevel === 'high'
                  ? 'LOS E (Heavy Congestion)'
                  : losLevel === 'moderate'
                  ? 'LOS C (Constrained Flow)'
                  : 'LOS A (Free Flow)'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Camera Controls & Sector Mapping Toolbar */}
      <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Hardware Device Selector (Webcam / Rear Phone Camera / DroidCam) */}
          {sourceType === 'webcam' && (
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="font-semibold text-slate-700">Camera Source:</span>
              <select
                value={selectedDeviceId}
                onChange={(e) => {
                  setSelectedDeviceId(e.target.value);
                  startCamera(e.target.value);
                }}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-medium text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500"
              >
                {videoDevices.map((d, idx) => (
                  <option key={d.deviceId} value={d.deviceId}>
                    {d.label || `Camera ${idx + 1}`}
                  </option>
                ))}
              </select>

              <button
                onClick={flipCameraFacing}
                className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                title="Flip to back or front camera"
              >
                <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                <span>Flip (Back / Front)</span>
              </button>
            </div>
          )}

          {/* Sector Mapping & Push Telemetry Button */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold text-slate-700">Map Feed to Venue Sector:</span>
            <select
              value={mappedSectorId}
              onChange={(e) => setMappedSectorId(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-medium text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500"
            >
              {currentEvent.zones.map((z) => (
                <option key={z.id} value={z.id}>
                  {z.name} ({z.code})
                </option>
              ))}
            </select>

            <button
              onClick={handlePushTelemetry}
              className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Push to Sector Telemetry</span>
            </button>
          </div>
        </div>

        {/* OpenCV Layer Filter Toggles */}
        <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-700 mr-1">AI Visual Overlays:</span>

            <button
              onClick={() => setShowBoundingBoxes(!showBoundingBoxes)}
              className={`px-3 py-1.5 rounded-lg border font-semibold transition-all ${
                showBoundingBoxes
                  ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
              }`}
            >
              Bounding Boxes ({showBoundingBoxes ? 'ON' : 'OFF'})
            </button>

            <button
              onClick={() => setShowOpticalFlow(!showOpticalFlow)}
              className={`px-3 py-1.5 rounded-lg border font-semibold transition-all ${
                showOpticalFlow
                  ? 'bg-cyan-700 text-white border-cyan-800 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
              }`}
            >
              Optical Flow Vectors ({showOpticalFlow ? 'ON' : 'OFF'})
            </button>

            <button
              onClick={() => setShowHeatmap(!showHeatmap)}
              className={`px-3 py-1.5 rounded-lg border font-semibold transition-all ${
                showHeatmap
                  ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
              }`}
            >
              Density Heatmap ({showHeatmap ? 'ON' : 'OFF'})
            </button>

            <button
              onClick={() => setEnablePrivacyBlur(!enablePrivacyBlur)}
              className={`px-3 py-1.5 rounded-lg border font-semibold transition-all flex items-center gap-1 ${
                enablePrivacyBlur
                  ? 'bg-slate-900 text-white border-slate-950 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {enablePrivacyBlur ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>Privacy Blur</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600">Sensitivity:</span>
            <input
              type="range"
              min="15"
              max="55"
              value={sensitivity}
              onChange={(e) => setSensitivity(Number(e.target.value))}
              className="w-24 accent-emerald-600 cursor-pointer"
            />
            <span className="font-mono text-slate-500">{sensitivity}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
