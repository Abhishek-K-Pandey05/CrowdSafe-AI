import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { GoogleMapsView } from './GoogleMapsView';
import {
  Search,
  Filter,
  Calendar,
  MapPin,
  Users,
  Shield,
  Activity,
  AlertTriangle,
  ArrowRight,
  Compass,
  LayoutDashboard,
  CheckCircle2,
  Clock,
  Sparkles,
  Map,
  Grid,
} from 'lucide-react';
import { CrowdDensityLevel, EventData } from '../types';

export const EventExplorerView: React.FC = () => {
  const {
    events,
    setSelectedEventId,
    setCurrentView,
    isManager,
    loginAsManager,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'both' | 'map' | 'cards'>('both');

  // Filter events by search & category
  const filteredEvents = useMemo(() => {
    return events.filter((evt) => {
      const matchesSearch =
        evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        evt.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
        evt.city.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        selectedCategory === 'all' || evt.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [events, searchQuery, selectedCategory]);

  // Separate Ongoing vs Upcoming
  const ongoingEvents = useMemo(
    () => filteredEvents.filter((e) => e.timingStatus === 'ongoing'),
    [filteredEvents]
  );

  const upcomingEvents = useMemo(
    () => filteredEvents.filter((e) => e.timingStatus === 'upcoming'),
    [filteredEvents]
  );

  const getCrowdStatusBadge = (level: CrowdDensityLevel) => {
    switch (level) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-red-100 text-red-800 border border-red-200">
            <AlertTriangle className="w-3 h-3 text-red-600" />
            <span>Critical Volume</span>
          </span>
        );
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            <span>High Volume</span>
          </span>
        );
      case 'moderate':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            <Activity className="w-3 h-3 text-blue-600" />
            <span>Moderate Flow</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Low / Calm Flow</span>
          </span>
        );
    }
  };

  const handleSelectMap = (id: string) => {
    setSelectedEventId(id);
    setCurrentView('map');
  };

  const handleSelectAttendee = (id: string) => {
    setSelectedEventId(id);
    setCurrentView('attendee');
  };

  const handleSelectDashboard = (id: string) => {
    setSelectedEventId(id);
    if (!isManager) {
      loginAsManager();
    }
    setCurrentView('dashboard');
  };

  const renderEventCard = (evt: EventData, isOngoing: boolean) => {
    const occupancyPct = Math.round((evt.estimatedOccupancy / evt.totalCapacity) * 100);

    return (
      <div
        key={evt.id}
        className={`bg-white rounded-xl border shadow-xs hover:shadow-md transition-shadow p-5 sm:p-6 flex flex-col justify-between ${
          isOngoing ? 'border-red-200 ring-1 ring-red-100' : 'border-slate-200'
        }`}
      >
        <div>
          {/* Top Meta Line */}
          <div className="flex items-center justify-between gap-2 text-xs mb-2">
            <div className="flex items-center gap-2">
              <span
                className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                  isOngoing
                    ? 'bg-red-100 text-red-800 border-red-200'
                    : 'bg-sky-100 text-sky-800 border-sky-200'
                }`}
              >
                {isOngoing ? '● LIVE TODAY' : '○ UPCOMING'}
              </span>
              <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                {evt.category}
              </span>
            </div>
            {getCrowdStatusBadge(evt.overallCrowdLevel)}
          </div>

          {/* Title & Venue */}
          <h3 className="text-lg font-bold text-slate-900 leading-snug">{evt.title}</h3>

          <div className="mt-2 space-y-1 text-xs text-slate-600">
            <p className="flex items-start gap-1.5 font-medium text-slate-800">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
              <span>{evt.venue}</span>
            </p>
            <p className="flex items-center gap-1.5 text-slate-500">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{evt.date} · {evt.timeRange}</span>
            </p>
          </div>

          <p className="mt-3 text-xs text-slate-500 leading-relaxed line-clamp-2">
            {evt.description}
          </p>

          {/* Capacity Progress Bar */}
          <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">
                {isOngoing ? 'Current Estimated Attendance:' : 'Licensed Event Capacity:'}
              </span>
              <span className="font-semibold text-slate-800">
                {evt.estimatedOccupancy.toLocaleString()} / {evt.totalCapacity.toLocaleString()} ({occupancyPct}%)
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <div
                className={`h-2 rounded-full transition-all duration-500 ${
                  isOngoing
                    ? occupancyPct >= 75
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                    : 'bg-slate-400'
                }`}
                style={{ width: `${Math.min(100, occupancyPct)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card Action Buttons */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleSelectMap(evt.id)}
            className="flex-1 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <span>Venue Safety Map</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => handleSelectAttendee(evt.id)}
            className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md transition-colors"
          >
            Attendee Guide
          </button>

          <button
            onClick={() => handleSelectDashboard(evt.id)}
            className="py-2 px-2.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            title="Open Safety Operations Dashboard"
          >
            <LayoutDashboard className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
            <Compass className="w-4 h-4 text-emerald-600" />
            <span>Nagpur Public Event Safety Directory</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Nagpur Public Events & Venue Locations
          </h1>
          <p className="mt-1 text-sm text-slate-600 max-w-2xl">
            Real-time crowd flow, egress corridors, and location mapping for public events across Nagpur, Maharashtra.
          </p>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 p-1 bg-white border border-slate-200 rounded-lg shadow-xs text-xs self-start md:self-auto">
          <button
            onClick={() => setViewMode('both')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              viewMode === 'both' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Map & List View
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 ${
              viewMode === 'map' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Map className="w-3.5 h-3.5 text-emerald-400" />
            <span>Google Map Only</span>
          </button>
          <button
            onClick={() => setViewMode('cards')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 ${
              viewMode === 'cards' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Cards Only</span>
          </button>
        </div>
      </div>

      {/* Google Map Section */}
      {(viewMode === 'both' || viewMode === 'map') && (
        <section className="space-y-2">
          <GoogleMapsView showHeader={true} height="h-[460px] sm:h-[520px]" />
        </section>
      )}

      {/* Search and Filters Bar */}
      {(viewMode === 'both' || viewMode === 'cards') && (
        <>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by event name, venue (e.g., Symbiosis, Vasantrao Deshpande, WHC Road)..."
                  className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Category Filter */}
              <div className="shrink-0 flex items-center gap-2">
                <span className="text-xs font-medium text-slate-500 hidden sm:inline">Category:</span>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">All Categories</option>
                  <option value="Job Fair & Skills">Job Fair & Skills</option>
                  <option value="Sports Festival">Sports Festival</option>
                  <option value="Property & Business Expo">Property & Business Expo</option>
                  <option value="Comedy & Entertainment">Comedy & Entertainment</option>
                  <option value="Cultural & Music">Cultural & Music</option>
                  <option value="Handloom & Exhibition">Handloom & Exhibition</option>
                  <option value="Theatre & Drama">Theatre & Drama</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 1: ONGOING EVENTS */}
          <section className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b-2 border-red-500">
              <div className="flex items-center gap-2.5">
                <span className="w-3 h-3 rounded-full bg-red-600 animate-ping inline-block" />
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                  Ongoing Events (Live Today · 29 September 2026)
                </h2>
              </div>
              <span className="text-xs font-bold text-red-700 bg-red-50 px-2.5 py-1 rounded border border-red-200">
                {ongoingEvents.length} Active in Nagpur
              </span>
            </div>

            {ongoingEvents.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 text-xs">
                No ongoing events match your search query.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {ongoingEvents.map((evt) => renderEventCard(evt, true))}
              </div>
            )}
          </section>

          {/* SECTION 2: UPCOMING EVENTS */}
          <section className="space-y-4 pt-6">
            <div className="flex items-center justify-between pb-2 border-b-2 border-sky-600">
              <div className="flex items-center gap-2.5">
                <Calendar className="w-5 h-5 text-sky-600" />
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                  Upcoming Events (Nagpur Scheduled)
                </h2>
              </div>
              <span className="text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded border border-sky-200">
                {upcomingEvents.length} Scheduled
              </span>
            </div>

            {upcomingEvents.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 text-xs">
                No upcoming events match your search query.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {upcomingEvents.map((evt) => renderEventCard(evt, false))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
};
