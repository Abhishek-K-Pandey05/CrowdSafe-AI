import React, { useState, useRef, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Zone, Amenity, CrowdDensityLevel } from '../types';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Layers,
  MapPin,
  Compass,
  AlertTriangle,
  HeartPulse,
  Droplets,
  DoorOpen,
  ArrowRight,
  Accessibility,
  Info,
  CheckCircle2,
  Navigation,
  Eye,
  Shield,
  X,
  Volume2,
} from 'lucide-react';

interface InteractiveMapProps {
  interactive?: boolean;
  compact?: boolean;
  showZonePanel?: boolean;
  onZoneSelect?: (zone: Zone) => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  interactive = true,
  compact = false,
  showZonePanel = true,
  onZoneSelect,
}) => {
  const {
    currentEvent,
    selectedZoneId,
    setSelectedZoneId,
    userLocation,
    requestUserLocation,
    stopSharingLocation,
    setManualLocation,
    activeRoute,
    settings,
    openAuthModal,
    isManager,
  } = useApp();

  // Zoom & Pan state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [layerFilter, setLayerFilter] = useState<'all' | 'density' | 'flow' | 'amenities'>('all');
  const [isManualPinMode, setIsManualPinMode] = useState(false);

  const containerRef = useRef<HTMLDivElement | null>(null);

  const selectedZone = useMemo(
    () => currentEvent.zones.find((z) => z.id === selectedZoneId) || null,
    [currentEvent, selectedZoneId]
  );

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 2.5));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.75));
  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!interactive) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Click on map container for manual pin placement if enabled
  const handleMapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isManualPinMode) return;
    const svgRect = e.currentTarget.getBoundingClientRect();
    const clickX = ((e.clientX - svgRect.left) / svgRect.width) * 100;
    const clickY = ((e.clientY - svgRect.top) / svgRect.height) * 100;

    // Find closest zone
    let closestZone = currentEvent.zones[0];
    let minDist = 999999;
    currentEvent.zones.forEach((z) => {
      const zcx = z.x + z.width / 2;
      const zcy = z.y + z.height / 2;
      const d = Math.hypot(zcx - clickX, zcy - clickY);
      if (d < minDist) {
        minDist = d;
        closestZone = z;
      }
    });

    setManualLocation(Math.round(clickX), Math.round(clickY), closestZone.id);
    setIsManualPinMode(false);
  };

  const handleZoneClick = (zone: Zone, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedZoneId(zone.id);
    if (onZoneSelect) onZoneSelect(zone);
  };

  // Color & pattern helpers for accessible density
  const getDensityColor = (level: CrowdDensityLevel) => {
    switch (level) {
      case 'critical':
        return {
          fill: 'rgba(239, 68, 68, 0.28)',
          stroke: '#dc2626',
          textClass: 'text-red-700',
          badgeBg: 'bg-red-100 border-red-300 text-red-800',
          label: 'Critical Density',
        };
      case 'high':
        return {
          fill: 'rgba(245, 158, 11, 0.24)',
          stroke: '#d97706',
          textClass: 'text-amber-700',
          badgeBg: 'bg-amber-100 border-amber-300 text-amber-800',
          label: 'High Volume',
        };
      case 'moderate':
        return {
          fill: 'rgba(59, 130, 246, 0.18)',
          stroke: '#2563eb',
          textClass: 'text-blue-700',
          badgeBg: 'bg-blue-100 border-blue-300 text-blue-800',
          label: 'Moderate Flow',
        };
      default:
        return {
          fill: 'rgba(16, 185, 129, 0.18)',
          stroke: '#059669',
          textClass: 'text-emerald-700',
          badgeBg: 'bg-emerald-100 border-emerald-300 text-emerald-800',
          label: 'Calm & Free Flowing',
        };
    }
  };

  const getAmenityIcon = (type: Amenity['type']) => {
    switch (type) {
      case 'exit':
        return <DoorOpen className="w-3.5 h-3.5 text-emerald-700" />;
      case 'first-aid':
        return <HeartPulse className="w-3.5 h-3.5 text-red-600" />;
      case 'water':
        return <Droplets className="w-3.5 h-3.5 text-sky-600" />;
      case 'restroom':
        return <span className="text-[10px] font-bold text-indigo-700 font-mono">WC</span>;
      case 'accessible-ramp':
        return <Accessibility className="w-3.5 h-3.5 text-violet-700" />;
      default:
        return <Info className="w-3.5 h-3.5 text-slate-700" />;
    }
  };

  return (
    <div className="relative w-full rounded-xl bg-slate-900 border border-slate-700 overflow-hidden shadow-md select-none">
      {/* Map Control Bar Top */}
      <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Layer Filters */}
        <div className="pointer-events-auto flex items-center gap-1 bg-slate-800/90 backdrop-blur-md p-1 rounded-lg border border-slate-700 text-xs shadow-md">
          <button
            onClick={() => setLayerFilter('all')}
            className={`px-2.5 py-1 rounded font-medium transition-colors ${
              layerFilter === 'all' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            All Overlays
          </button>
          <button
            onClick={() => setLayerFilter('density')}
            className={`px-2.5 py-1 rounded font-medium transition-colors ${
              layerFilter === 'density' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            Density Heat
          </button>
          <button
            onClick={() => setLayerFilter('flow')}
            className={`px-2.5 py-1 rounded font-medium transition-colors ${
              layerFilter === 'flow' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            Movement Vectors
          </button>
          <button
            onClick={() => setLayerFilter('amenities')}
            className={`px-2.5 py-1 rounded font-medium transition-colors ${
              layerFilter === 'amenities' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            Exits & Aid
          </button>
        </div>

        {/* Location Pin & Geolocation Controls */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-800/90 backdrop-blur-md p-1 rounded-lg border border-slate-700 text-xs shadow-md">
          {userLocation.active ? (
            <div className="flex items-center gap-2 px-2 py-0.5">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                <span>You Are Here</span>
              </span>
              <span className="text-[10px] text-slate-400">({userLocation.isSimulated ? 'Simulated' : 'GPS'})</span>
              <button
                onClick={stopSharingLocation}
                className="text-slate-400 hover:text-red-400 ml-1 p-0.5"
                title="Stop location pin"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1">
              <button
                onClick={requestUserLocation}
                className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-100 font-medium flex items-center gap-1 transition-colors"
                title="Request device GPS to show nearest exits"
              >
                <Navigation className="w-3.5 h-3.5 text-emerald-400" />
                <span>Show My Location</span>
              </button>
              <button
                onClick={() => setIsManualPinMode(true)}
                className={`px-2 py-1 rounded text-slate-300 hover:text-white transition-colors ${
                  isManualPinMode ? 'bg-amber-600 text-white' : 'hover:bg-slate-700'
                }`}
                title="Tap anywhere on map to manually position yourself"
              >
                <MapPin className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Manual Pin Placement Notice Banner */}
      {isManualPinMode && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-amber-500 text-slate-900 text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg flex items-center gap-2 animate-bounce">
          <MapPin className="w-3.5 h-3.5" />
          <span>Click anywhere on the map to place your pin</span>
          <button
            onClick={() => setIsManualPinMode(false)}
            className="ml-1 text-slate-900 hover:text-black font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* Geolocation Denied / Fallback Message */}
      {userLocation.error && (
        <div className="absolute top-16 left-4 right-4 z-30 bg-amber-950/90 text-amber-200 border border-amber-800 text-xs p-2.5 rounded-lg flex items-center justify-between gap-2 shadow-lg">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{userLocation.error}</span>
          </div>
          <button
            onClick={() => setIsManualPinMode(true)}
            className="shrink-0 underline text-amber-300 font-semibold"
          >
            Place Pin Manually
          </button>
        </div>
      )}

      {/* Map Zoom / Navigation Controls Top Right */}
      <div className="absolute bottom-4 right-4 z-20 flex flex-col gap-1.5 bg-slate-800/90 backdrop-blur-md p-1 rounded-lg border border-slate-700 shadow-md">
        <button
          onClick={handleZoomIn}
          aria-label="Zoom in"
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={handleZoomOut}
          aria-label="Zoom out"
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={handleReset}
          aria-label="Reset map view"
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Transparent Simulation Indicator Badge (Bottom Left) */}
      <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-400">
        <span className="w-2 h-2 rounded-full bg-emerald-500" />
        <span>Venue Map · Simulated Telemetry</span>
      </div>

      {/* SVG Canvas Map Surface */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className={`w-full ${compact ? 'h-[360px]' : 'h-[520px] sm:h-[600px]'} cursor-grab ${
          isDragging ? 'cursor-grabbing' : ''
        } overflow-hidden bg-slate-950 flex items-center justify-center relative`}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full object-contain"
          onClick={handleMapClick}
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          <defs>
            {/* Background Venue Texture */}
            <pattern id="venue-grid" width="5" height="5" patternUnits="userSpaceOnUse">
              <path d="M 5 0 L 0 0 0 5" fill="none" stroke="rgba(255, 255, 255, 0.03)" strokeWidth="0.2" />
            </pattern>

            {/* Diagonal Hash Pattern for High Density */}
            <pattern id="hash-high" width="4" height="4" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="4" stroke="rgba(245, 158, 11, 0.35)" strokeWidth="1" />
            </pattern>
            <pattern id="hash-critical" width="4" height="4" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="4" stroke="rgba(239, 68, 68, 0.45)" strokeWidth="1.2" />
            </pattern>

            {/* Arrow Marker for Movement Flow */}
            <marker id="flow-arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
              <path d="M 0 1 L 9 5 L 0 9 z" fill="#10b981" />
            </marker>
            <marker id="flow-arrow-amber" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
              <path d="M 0 1 L 9 5 L 0 9 z" fill="#f59e0b" />
            </marker>
          </defs>

          {/* Venue Outer Perimeter Background */}
          <rect width="100" height="100" fill="url(#venue-grid)" />

          {/* Venue Boundary Line */}
          <rect
            x="3"
            y="3"
            width="94"
            height="94"
            rx="5"
            fill="rgba(15, 23, 42, 0.85)"
            stroke="rgba(148, 163, 184, 0.25)"
            strokeWidth="0.8"
          />

          {/* Accessible Major Corridors & Pathways */}
          <path
            d="M 50 6 L 50 94 M 6 50 L 94 50 M 20 20 L 80 80 M 20 80 L 80 20"
            fill="none"
            stroke="rgba(255, 255, 255, 0.08)"
            strokeWidth="1.5"
            strokeDasharray="2, 2"
          />

          {/* Active Calmed Route Visualization (if active) */}
          {activeRoute && (
            <g className="route-path-overlay">
              <polyline
                points="42,18 72,45 35,80"
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeDasharray="3, 2"
                strokeLinecap="round"
                className="animate-pulse"
              />
            </g>
          )}

          {/* Venue Zones */}
          {currentEvent.zones.map((zone) => {
            const isSelected = zone.id === selectedZoneId;
            const densityStyle = getDensityColor(zone.densityLevel);
            const showDensity = layerFilter === 'all' || layerFilter === 'density';
            const showFlow = layerFilter === 'all' || layerFilter === 'flow';

            return (
              <g
                key={zone.id}
                onClick={(e) => handleZoneClick(zone, e)}
                className="cursor-pointer transition-transform hover:opacity-95"
              >
                {/* Zone Area Shape */}
                <rect
                  x={zone.x}
                  y={zone.y}
                  width={zone.width}
                  height={zone.height}
                  rx="3"
                  fill={showDensity ? densityStyle.fill : 'rgba(30, 41, 59, 0.6)'}
                  stroke={isSelected ? '#38bdf8' : densityStyle.stroke}
                  strokeWidth={isSelected ? '1.8' : '0.8'}
                  className="transition-all duration-200"
                />

                {/* Pattern Overlay for high/critical to ensure accessibility beyond color */}
                {showDensity && zone.densityLevel === 'high' && (
                  <rect
                    x={zone.x}
                    y={zone.y}
                    width={zone.width}
                    height={zone.height}
                    rx="3"
                    fill="url(#hash-high)"
                    pointerEvents="none"
                  />
                )}
                {showDensity && zone.densityLevel === 'critical' && (
                  <rect
                    x={zone.x}
                    y={zone.y}
                    width={zone.width}
                    height={zone.height}
                    rx="3"
                    fill="url(#hash-critical)"
                    pointerEvents="none"
                  />
                )}

                {/* Zone Code & Name */}
                <text
                  x={zone.x + zone.width / 2}
                  y={zone.y + 4.5}
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize="2.4"
                  fontWeight="600"
                  className="pointer-events-none drop-shadow-sm font-sans"
                >
                  {zone.name}
                </text>

                {/* Zone Density Tag (Text + Value, not color alone) */}
                <text
                  x={zone.x + zone.width / 2}
                  y={zone.y + 8.2}
                  textAnchor="middle"
                  fill={zone.densityLevel === 'critical' ? '#fca5a5' : zone.densityLevel === 'high' ? '#fde68a' : '#a7f3d0'}
                  fontSize="2"
                  fontWeight="500"
                  className="pointer-events-none font-mono"
                >
                  {zone.densityPerM2} ppl/m² · {zone.densityLevel.toUpperCase()}
                </text>

                {/* Flow Direction Indicator Arrow */}
                {showFlow && (
                  <g
                    transform={`translate(${zone.x + zone.width / 2}, ${zone.y + zone.height - 4}) rotate(${
                      zone.flowDirection.angleDeg
                    })`}
                    className="pointer-events-none"
                  >
                    <line
                      x1="-3"
                      y1="0"
                      x2="3"
                      y2="0"
                      stroke={zone.densityLevel === 'high' || zone.densityLevel === 'critical' ? '#f59e0b' : '#10b981'}
                      strokeWidth="0.8"
                      markerEnd={
                        zone.densityLevel === 'high' || zone.densityLevel === 'critical'
                          ? 'url(#flow-arrow-amber)'
                          : 'url(#flow-arrow)'
                      }
                    />
                  </g>
                )}
              </g>
            );
          })}

          {/* Amenities & Safe Infrastructure Overlays */}
          {(layerFilter === 'all' || layerFilter === 'amenities') &&
            currentEvent.amenities.map((am) => (
              <g
                key={am.id}
                transform={`translate(${am.x}, ${am.y})`}
                className="cursor-pointer"
              >
                <title>{`${am.name} (${am.status})`}</title>
                {/* Circular Pin Base */}
                <circle
                  r="2.2"
                  fill="#ffffff"
                  stroke={am.type === 'exit' ? '#10b981' : am.type === 'first-aid' ? '#ef4444' : '#0284c7'}
                  strokeWidth="0.6"
                  className="shadow-sm"
                />
                {/* Amenity label text */}
                <text
                  y="4.2"
                  textAnchor="middle"
                  fill="#cbd5e1"
                  fontSize="1.6"
                  fontWeight="500"
                  className="pointer-events-none font-sans"
                >
                  {am.name.split(' ')[0]}
                </text>
              </g>
            ))}

          {/* User Location Pin ("You Are Here") */}
          {userLocation.active && userLocation.mapX !== undefined && userLocation.mapY !== undefined && (
            <g transform={`translate(${userLocation.mapX}, ${userLocation.mapY})`} className="user-pin-marker">
              {/* Outer Pulse Ring */}
              <circle
                r="3.8"
                fill="none"
                stroke="#10b981"
                strokeWidth="0.5"
                opacity="0.8"
                className="animate-ping"
              />
              {/* Main Pin */}
              <circle r="2.2" fill="#10b981" stroke="#ffffff" strokeWidth="0.8" />
              <circle r="0.8" fill="#ffffff" />
              {/* Label */}
              <rect x="-6" y="-5.5" width="12" height="3" rx="1" fill="rgba(15, 23, 42, 0.9)" />
              <text
                x="0"
                y="-3.4"
                textAnchor="middle"
                fill="#ffffff"
                fontSize="1.6"
                fontWeight="700"
                className="font-sans"
              >
                YOU ARE HERE
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Map Legend (Bottom Strip) */}
      <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Crowd Status:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-emerald-500" />
            <span className="text-slate-300">Low (&lt;1.5/m²)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-blue-500" />
            <span className="text-slate-300">Moderate (1.5-2.5)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-amber-500" />
            <span className="text-slate-300">High (2.6-3.9)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-red-500" />
            <span className="text-slate-300">Critical (≥4.0)</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <DoorOpen className="w-3.5 h-3.5 text-emerald-400" /> Exit Portal
          </span>
          <span className="flex items-center gap-1">
            <HeartPulse className="w-3.5 h-3.5 text-red-400" /> First Aid
          </span>
          <span className="flex items-center gap-1">
            <Droplets className="w-3.5 h-3.5 text-sky-400" /> Water Station
          </span>
        </div>
      </div>

      {/* Zone Detail Panel Drawer (When a zone is selected) */}
      {showZonePanel && selectedZone && (
        <div className="bg-white border-t border-slate-200 p-4 sm:p-5 text-slate-900 animate-in slide-in-from-bottom-2 duration-150">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            {/* Zone Title & Capacity */}
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                  {selectedZone.code}
                </span>
                <h3 className="text-base font-bold text-slate-900">{selectedZone.name}</h3>
                <span
                  className={`text-xs font-semibold px-2 py-0.5 rounded border ${
                    getDensityColor(selectedZone.densityLevel).badgeBg
                  }`}
                >
                  {getDensityColor(selectedZone.densityLevel).label}
                </span>
              </div>
              <p className="text-xs text-slate-600">{selectedZone.notes}</p>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center text-xs">
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Density</p>
                <p className="font-bold text-slate-800 text-sm">{selectedZone.densityPerM2} ppl/m²</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Occupancy</p>
                <p className="font-bold text-slate-800 text-sm">
                  {selectedZone.currentOccupancy.toLocaleString()} / {selectedZone.licensedCapacity.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Trend</p>
                <p
                  className={`font-bold capitalize text-sm ${
                    selectedZone.trend === 'rising'
                      ? 'text-amber-600'
                      : selectedZone.trend === 'decreasing'
                      ? 'text-emerald-600'
                      : 'text-slate-700'
                  }`}
                >
                  {selectedZone.trend}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Flow Rate</p>
                <p className="font-bold text-slate-800 text-sm">{selectedZone.flowRatePerMin} / min</p>
              </div>
            </div>
          </div>

          {/* Action & Exits Row */}
          <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-800">Proactive Guidance: </span>
                <span className="text-slate-600">{selectedZone.suggestedAction}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-slate-500 font-medium">Nearest Safe Egress:</span>
              <span className="font-semibold text-slate-800">
                {selectedZone.nearbyExits.join(', ')}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
