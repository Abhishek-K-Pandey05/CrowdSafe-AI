import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  AlertTriangle,
  CheckCircle2,
  Clock,
  UserCheck,
  MessageSquare,
  ShieldCheck,
  History,
  Activity,
  Send,
} from 'lucide-react';
import { AlertSeverity } from '../types';

export const AlertDetailModal: React.FC = () => {
  const {
    selectedAlertId,
    setSelectedAlertId,
    alerts,
    acknowledgeAlert,
    assignAlert,
    addAlertNote,
    resolveAlert,
    currentEvent,
    currentUser,
    isManager,
  } = useApp();

  const [assigneeInput, setAssigneeInput] = useState('Steward Alpha (North Gate)');
  const [newNote, setNewNote] = useState('');
  const [resolutionText, setResolutionText] = useState('');
  const [isResolving, setIsResolving] = useState(false);

  const alert = alerts.find((a) => a.id === selectedAlertId);
  if (!alert) return null;

  const getSeverityBadge = (sev: AlertSeverity) => {
    switch (sev) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-100 border border-red-300 text-red-800 text-xs font-bold">
            <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
            <span>CRITICAL (Immediate Action)</span>
          </span>
        );
      case 'high':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-amber-100 border border-amber-300 text-amber-800 text-xs font-bold">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>HIGH (Intervention Required)</span>
          </span>
        );
      case 'moderate':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-blue-100 border border-blue-300 text-blue-800 text-xs font-bold">
            <Activity className="w-3.5 h-3.5 text-blue-600" />
            <span>MODERATE (Monitoring)</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold">
            <Clock className="w-3.5 h-3.5 text-slate-600" />
            <span>ADVISORY (Baseline Watch)</span>
          </span>
        );
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    addAlertNote(alert.id, newNote);
    setNewNote('');
  };

  const handleResolve = () => {
    resolveAlert(alert.id, resolutionText || 'Bottleneck dispersed. Flow restored to baseline.');
    setIsResolving(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="alert-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="relative bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 sm:p-7 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={() => setSelectedAlertId(null)}
          aria-label="Close alert details"
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="pb-4 border-b border-slate-200 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            {getSeverityBadge(alert.severity)}
            <span className="text-xs text-slate-500 font-mono">ID: {alert.id}</span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">{alert.timestamp}</span>
          </div>

          <h2 id="alert-modal-title" className="text-lg font-bold text-slate-900 leading-snug">
            {alert.title}
          </h2>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
            <span>
              <strong>Location:</strong> {alert.zoneName}
            </span>
            <span>·</span>
            <span>
              <strong>Sensor Feed:</strong> {alert.confidence}
            </span>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="py-4 space-y-5 max-h-[65vh] overflow-y-auto pr-1 text-xs">
          {/* Observed Dynamics */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">
              Observed Dynamic Change
            </h3>
            <p className="text-slate-700 leading-relaxed">{alert.observedChange}</p>
          </div>

          {/* Recommended Action */}
          <div className="p-3.5 bg-emerald-50/70 rounded-lg border border-emerald-200 space-y-1.5">
            <div className="flex items-center gap-1.5 text-emerald-900 font-semibold uppercase tracking-wider text-[11px]">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Recommended Proactive Intervention</span>
            </div>
            <p className="text-emerald-950 font-medium leading-relaxed">{alert.recommendedAction}</p>
          </div>

          {/* Current Status & Action Bar */}
          <div className="p-4 bg-slate-100/70 rounded-lg border border-slate-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold block">
                  Current Triage Status
                </span>
                <span className="font-bold text-sm text-slate-900 capitalize">
                  {alert.status} {alert.assignedTo ? `(Assigned: ${alert.assignedTo})` : ''}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                {alert.status === 'active' && (
                  <button
                    onClick={() => acknowledgeAlert(alert.id)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium shadow-xs transition-colors"
                  >
                    Acknowledge
                  </button>
                )}

                {alert.status !== 'resolved' && (
                  <button
                    onClick={() => setIsResolving((prev) => !prev)}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-medium shadow-xs transition-colors"
                  >
                    Resolve Alert
                  </button>
                )}
              </div>
            </div>

            {/* Assignment Dropdown */}
            {alert.status !== 'resolved' && (
              <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <span className="text-slate-700 font-medium shrink-0">Dispatch Response Team:</span>
                <select
                  value={assigneeInput}
                  onChange={(e) => setAssigneeInput(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {currentEvent.stewardTeams.map((team) => (
                    <option key={team.id} value={`${team.name} (${team.lead})`}>
                      {team.name} — {team.lead} [{team.status}]
                    </option>
                  ))}
                  <option value="Paramedic Rapid Response 1">Paramedic Rapid Response 1</option>
                  <option value="Gate Egress Marshal Alpha">Gate Egress Marshal Alpha</option>
                </select>
                <button
                  onClick={() => assignAlert(alert.id, assigneeInput)}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded font-medium shadow-xs transition-colors shrink-0"
                >
                  Assign & Dispatch
                </button>
              </div>
            )}

            {/* Resolution Form if opened */}
            {isResolving && (
              <div className="pt-3 border-t border-slate-200 space-y-2">
                <label className="block text-[11px] font-semibold text-slate-700">
                  Resolution Summary / De-escalation Notes:
                </label>
                <textarea
                  rows={2}
                  value={resolutionText}
                  onChange={(e) => setResolutionText(e.target.value)}
                  placeholder="e.g. Queue divider ropes deployed. Pedestrian velocity restored to 1.1 m/s."
                  className="w-full p-2 bg-white border border-slate-300 rounded text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setIsResolving(false)}
                    className="px-2.5 py-1 text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleResolve}
                    className="px-3 py-1 bg-emerald-700 text-white rounded font-medium hover:bg-emerald-800"
                  >
                    Confirm Resolution
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Internal Notes Thread */}
          <div className="space-y-2.5">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
              <span>Internal Dispatch Notes ({alert.internalNotes.length})</span>
            </h3>

            {alert.internalNotes.length === 0 ? (
              <p className="text-slate-400 italic">No notes added yet.</p>
            ) : (
              <div className="space-y-2">
                {alert.internalNotes.map((note) => (
                  <div key={note.id} className="p-2.5 bg-slate-50 rounded border border-slate-200 space-y-0.5">
                    <div className="flex items-center justify-between text-[10px] text-slate-500">
                      <span className="font-semibold text-slate-800">{note.author}</span>
                      <span>{note.time}</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed">{note.text}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Add Note Form */}
            <form onSubmit={handleAddNote} className="flex gap-2 pt-1">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add operational observation or field update..."
                className="flex-1 px-3 py-2 border border-slate-300 rounded text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded font-medium flex items-center gap-1 shrink-0"
              >
                <Send className="w-3 h-3" />
                <span>Post</span>
              </button>
            </form>
          </div>

          {/* Audit History Timeline */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-slate-500" />
              <span>Audit History & Status Transitions</span>
            </h3>

            <div className="space-y-1.5 pl-2 border-l-2 border-slate-200">
              {alert.statusHistory.map((h, i) => (
                <div key={i} className="text-[11px] text-slate-600 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800 capitalize">[{h.status}]</span>
                    <span>by {h.by}</span>
                    <span className="text-slate-400">({h.time})</span>
                  </div>
                  {h.note && <p className="text-slate-500 italic pl-3">↳ {h.note}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => setSelectedAlertId(null)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-md transition-colors text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
