import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Info,
  Lock,
} from 'lucide-react';
import { DEMO_USERS } from '../data/mockEvents';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    authDefaultTab,
    loginAsAttendee,
    loginAsManager,
    loginWithCustom,
    setCurrentView,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'attendee' | 'manager'>(authDefaultTab);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [badgeCode, setBadgeCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  if (!isAuthModalOpen) return null;

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Please provide a valid email format (e.g. name@example.com).';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters.';
    }

    if (!name.trim()) {
      newErrors.name = 'Full name is required.';
    }

    if (activeTab === 'manager' && !badgeCode.trim()) {
      newErrors.badgeCode = 'Operational badge ID is required for manager verification.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    loginWithCustom(name, email, activeTab);
    if (activeTab === 'manager') {
      setCurrentView('dashboard');
    }
  };

  const handleQuickAttendee = () => {
    loginAsAttendee();
  };

  const handleQuickManager = () => {
    loginAsManager();
    setCurrentView('dashboard');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="relative bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 sm:p-7 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          aria-label="Close sign in dialog"
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-md bg-emerald-700 flex items-center justify-center text-white">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <h2 id="auth-modal-title" className="text-xl font-bold text-slate-900">
              Sign In to CrowdSafe
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            Select your role mode or sign in to access personalized crowd guidance and safety tools.
          </p>
        </div>

        {/* Role Switcher Tabs */}
        <div className="flex items-center p-1 bg-slate-100 rounded-lg mb-5" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'attendee'}
            onClick={() => {
              setActiveTab('attendee');
              setErrors({});
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'attendee'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5 text-emerald-600" />
            <span>Attendee Mode</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'manager'}
            onClick={() => {
              setActiveTab('manager');
              setErrors({});
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'manager'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-slate-800" />
            <span>Safety Manager</span>
          </button>
        </div>

        {/* 1-Click Fast Demo Fill Box */}
        <div className="mb-5 p-3.5 rounded-lg bg-emerald-50/70 border border-emerald-200">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-emerald-900 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Instant Demo Account</span>
            </span>
            <span className="text-[10px] text-emerald-700 font-mono">No password required</span>
          </div>

          {activeTab === 'attendee' ? (
            <div>
              <p className="text-xs text-emerald-800 mb-2">
                Sign in as <strong>{DEMO_USERS.attendee.name}</strong> to test live venue navigation, calm routing, and hydration points.
              </p>
              <button
                type="button"
                onClick={handleQuickAttendee}
                className="w-full py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-medium rounded-md shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <span>Continue as Maya Chen (Attendee)</span>
                <CheckCircle2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div>
              <p className="text-xs text-slate-800 mb-2">
                Sign in as <strong>{DEMO_USERS.manager.name}</strong> to access the real-time bottleneck queue, dispatch steward units, and adjust thresholds.
              </p>
              <button
                type="button"
                onClick={handleQuickManager}
                className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-md shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <span>Continue as Marcus Vance (Lead Safety Officer)</span>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              </button>
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="bg-white px-2 text-slate-400">or sign in with custom credentials</span>
          </div>
        </div>

        {/* Custom Form */}
        <form onSubmit={handleCustomSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={activeTab === 'manager' ? 'e.g. Inspector Jordan Blake' : 'e.g. Sarah Jenkins'}
              className={`w-full px-3 py-2 text-xs rounded-md border ${
                errors.name ? 'border-red-400 bg-red-50/20' : 'border-slate-300'
              } focus:outline-none focus:ring-2 focus:ring-emerald-500`}
            />
            {errors.name && <p className="mt-1 text-[11px] text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.name}</p>}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={activeTab === 'manager' ? 'safety@eventops.org' : 'name@example.com'}
              className={`w-full px-3 py-2 text-xs rounded-md border ${
                errors.email ? 'border-red-400 bg-red-50/20' : 'border-slate-300'
              } focus:outline-none focus:ring-2 focus:ring-emerald-500`}
            />
            {errors.email && <p className="mt-1 text-[11px] text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.email}</p>}
          </div>

          {activeTab === 'manager' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Operational Badge ID</label>
              <input
                type="text"
                value={badgeCode}
                onChange={(e) => setBadgeCode(e.target.value)}
                placeholder="e.g. CS-SAFETY-409"
                className={`w-full px-3 py-2 text-xs rounded-md border ${
                  errors.badgeCode ? 'border-red-400 bg-red-50/20' : 'border-slate-300'
                } focus:outline-none focus:ring-2 focus:ring-emerald-500`}
              />
              {errors.badgeCode && <p className="mt-1 text-[11px] text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.badgeCode}</p>}
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-medium text-slate-700">Password</label>
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="text-[11px] text-slate-500 hover:text-slate-800 flex items-center gap-1"
              >
                {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showPassword ? 'Hide' : 'Show'}</span>
              </button>
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className={`w-full px-3 py-2 text-xs rounded-md border ${
                errors.password ? 'border-red-400 bg-red-50/20' : 'border-slate-300'
              } focus:outline-none focus:ring-2 focus:ring-emerald-500`}
            />
            {errors.password && <p className="mt-1 text-[11px] text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.password}</p>}
          </div>

          <button
            type="submit"
            className="w-full mt-2 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-md shadow-xs transition-colors"
          >
            Sign In with Credentials
          </button>
        </form>

        {/* Demo Security Disclaimer */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-start gap-2 text-[11px] text-slate-500">
          <Info className="w-3.5 h-3.5 shrink-0 text-slate-400 mt-0.5" />
          <span>
            <strong>Client-Side Demo Session:</strong> Authentication state is maintained in-memory for testing purposes. No persistent backend accounts or hashed passwords are required.
          </span>
        </div>
      </div>
    </div>
  );
};
