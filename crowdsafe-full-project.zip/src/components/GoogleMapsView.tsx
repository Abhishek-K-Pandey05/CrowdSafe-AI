import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import { useApp } from '../context/AppContext';
import { EventData, CrowdDensityLevel } from '../types';
import {
  MapPin,
  Calendar,
  Clock,
  Compass,
  ArrowRight,
  Shield,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Navigation,
  Layers,
  Sparkles,
  Info,
  Locate,
  Eye,
  Crosshair,
} from 'lucide-react';

interface GoogleMapsViewProps {
  onSelectEvent?: (event: EventData) => void;
  selectedEventId?: string;
  height?: string;
  showHeader?: boolean;
}

export const GoogleMapsView: React.FC<GoogleMapsViewProps> = ({
  onSelectEvent,
  selectedEventId,
  height = 'h-[520px] sm:h-[600px]',
  showHeader = true,
}) => {
  const { events, setSelectedEventId, setCurrentView } = useApp();

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const userAccuracyCircleRef = useRef<L.Circle | null>(null);

  const [activeTimingFilter, setActiveTimingFilter] = useState<'all' | 'ongoing' | 'upcoming'>('all');
  const [selectedMapEvent, setSelectedMapEvent] = useState<EventData | null>(null);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number; accuracy?: number } | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [mapTileStyle, setMapTileStyle] = useState<'street'>('street');

  // Filter events based on ongoing vs upcoming
  const filteredEvents = useMemo(() => {
    if (activeTimingFilter === 'all') return events;
    return events.filter((e) => e.timingStatus === activeTimingFilter);
  }, [events, activeTimingFilter]);

  const ongoingCount = useMemo(() => events.filter((e) => e.timingStatus === 'ongoing').length, [events]);
  const upcomingCount = useMemo(() => events.filter((e) => e.timingStatus === 'upcoming').length, [events]);

  // Calculate distance between user and an event in km
  const getDistanceKm = (evtLat: number, evtLng: number): string | null => {
    if (!userCoords) return null;
    const R = 6371; // Earth's radius in km
    const dLat = ((evtLat - userCoords.lat) * Math.PI) / 180;
    const dLng = ((evtLng - userCoords.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((userCoords.lat * Math.PI) / 180) *
        Math.cos((evtLat * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c;
    return d < 1 ? `${Math.round(d * 1000)} m` : `${d.toFixed(1)} km`;
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (leafletMapRef.current) return;

    // Center on Nagpur
    const nagpurCenter: [number, number] = [21.1458, 79.0882];

    const map = L.map(mapContainerRef.current, {
      center: nagpurCenter,
      zoom: 12,
      zoomControl: false, // We'll add custom positioned zoom control
    });

    // Add zoom control top right
    L.control.zoom({ position: 'topright' }).addTo(map);

    // Standard OpenStreetMap tile layer
    const tileUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    const attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

    const tileLayer = L.tileLayer(tileUrl, {
      maxZoom: 19,
      attribution,
    }).addTo(map);

    const markersGroup = L.layerGroup().addTo(map);
    markersLayerRef.current = markersGroup;
    leafletMapRef.current = map;

    // Auto-detect user location on mount with low accuracy prompt
    handleGetLocation(false);

    return () => {
      map.remove();
      leafletMapRef.current = null;
    };
  }, []);

  // Update tile layer if style changes
  useEffect(() => {
    if (!leafletMapRef.current) return;
    const map = leafletMapRef.current;

    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    const tileUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

    L.tileLayer(tileUrl, {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);
  }, [mapTileStyle]);

  // Request browser location and render the live user location dot
  const handleGetLocation = (zoomToUser = true) => {
    if (!('geolocation' in navigator)) {
      setLocationError('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsLocating(false);
        const { latitude, longitude, accuracy } = position.coords;
        const coords = { lat: latitude, lng: longitude, accuracy };
        setUserCoords(coords);

        const map = leafletMapRef.current;
        if (!map) return;

        // Remove existing user marker & accuracy circle
        if (userMarkerRef.current) {
          map.removeLayer(userMarkerRef.current);
        }
        if (userAccuracyCircleRef.current) {
          map.removeLayer(userAccuracyCircleRef.current);
        }

        // Add soft accuracy circle
        const circle = L.circle([latitude, longitude], {
          radius: Math.min(accuracy || 100, 500),
          fillColor: '#3b82f6',
          fillOpacity: 0.12,
          color: '#2563eb',
          weight: 1,
        }).addTo(map);
        userAccuracyCircleRef.current = circle;

        // Custom pulsing blue dot HTML icon for Current Location
        const userDotIcon = L.divIcon({
          className: 'custom-user-location-marker',
          html: `
            <div class="relative flex items-center justify-center" style="width: 32px; height: 32px; transform: translate(-8px, -8px);">
              <span class="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-blue-500 opacity-60"></span>
              <span class="relative inline-flex rounded-full h-4 w-4 bg-blue-600 border-2 border-white shadow-lg"></span>
              <span class="absolute -bottom-5 whitespace-nowrap bg-blue-900/90 text-white text-[10px] font-bold px-1.5 py-0.2 rounded shadow">
                You Are Here
              </span>
            </div>
          `,
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        });

        const userMarker = L.marker([latitude, longitude], {
          icon: userDotIcon,
          zIndexOffset: 1000,
        }).addTo(map);

        userMarker.bindPopup(`
          <div style="font-family: system-ui, sans-serif; font-size: 12px; padding: 4px; min-width: 180px;">
            <div style="font-weight: 700; color: #1d4ed8; margin-bottom: 2px;">📍 Your Current Location</div>
            <div style="color: #64748b; font-size: 11px;">Coordinates: ${latitude.toFixed(4)}°, ${longitude.toFixed(4)}°</div>
            <div style="color: #64748b; font-size: 11px;">Accuracy: ~${Math.round(accuracy || 0)} meters</div>
            <div style="margin-top: 6px; font-size: 11px; color: #047857; font-weight: 600;">
              Active in CrowdSafe Session
            </div>
          </div>
        `);

        userMarkerRef.current = userMarker;

        if (zoomToUser) {
          map.setView([latitude, longitude], 14, { animate: true });
        }
      },
      (err) => {
        setIsLocating(false);
        console.warn('Geolocation error:', err);
        setLocationError('Location access was denied or unavailable. Tap anywhere or view Nagpur events.');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Render Event Markers
  useEffect(() => {
    const map = leafletMapRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    const bounds = L.latLngBounds([]);

    filteredEvents.forEach((evt) => {
      const isOngoing = evt.timingStatus === 'ongoing';
      const isSelected = selectedMapEvent?.id === evt.id;

      bounds.extend([evt.coordinates.lat, evt.coordinates.lng]);

      // Custom HTML Marker Icon
      const markerHtml = `
        <div class="relative cursor-pointer transition-transform hover:scale-110" style="transform: translate(-16px, -32px);">
          <div class="flex items-center justify-center w-8 h-8 rounded-full shadow-lg border-2 ${
            isOngoing
              ? 'bg-red-600 border-white text-white'
              : 'bg-sky-600 border-white text-white'
          }">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
          </div>
          ${
            isOngoing
              ? '<span class="absolute -top-1 -right-1 flex h-3 w-3"><span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span><span class="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span></span>'
              : ''
          }
          <div class="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap px-1.5 py-0.5 rounded text-[10px] font-bold shadow-md ${
            isOngoing
              ? 'bg-red-950 text-red-100 border border-red-800'
              : 'bg-slate-900 text-slate-100 border border-slate-700'
          }">
            ${evt.title.split(' ')[0]}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-event-map-pin',
        html: markerHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
      });

      const marker = L.marker([evt.coordinates.lat, evt.coordinates.lng], {
        icon: customIcon,
        title: evt.title,
      });

      // Marker Click Handler
      marker.on('click', () => {
        setSelectedMapEvent(evt);
        setSelectedEventId(evt.id);
        if (onSelectEvent) onSelectEvent(evt);

        // Open custom popup
        const distanceStr = getDistanceKm(evt.coordinates.lat, evt.coordinates.lng);

        const popupContent = `
          <div style="font-family: system-ui, sans-serif; padding: 2px; max-width: 250px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
              <span style="font-size: 10px; font-weight: 800; text-transform: uppercase; color: ${
                isOngoing ? '#dc2626' : '#0284c7'
              };">
                ${isOngoing ? '● LIVE TODAY' : '○ UPCOMING'}
              </span>
              <span style="font-size: 10px; background: #f1f5f9; padding: 1px 6px; border-radius: 4px; color: #475569; font-weight: 600;">
                ${evt.category}
              </span>
            </div>
            <div style="font-size: 13px; font-weight: 700; color: #0f172a; line-height: 1.3; margin-bottom: 4px;">
              ${evt.title}
            </div>
            <div style="font-size: 11px; color: #475569; margin-bottom: 4px;">
              📍 <strong>${evt.venue}</strong>
            </div>
            <div style="font-size: 11px; color: #64748b; margin-bottom: 6px;">
              🗓️ ${evt.date} (${evt.timeRange})
            </div>
            ${
              distanceStr
                ? `<div style="font-size: 11px; color: #0284c7; font-weight: 600; margin-bottom: 6px; background: #f0f9ff; padding: 2px 6px; border-radius: 4px;">
                    📏 ${distanceStr} from your current location
                   </div>`
                : ''
            }
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #e2e8f0; padding-top: 6px; font-size: 11px;">
              <span style="font-weight: 700; color: #334155;">Crowd: ${evt.overallCrowdLevel.toUpperCase()}</span>
              <span style="color: #059669; font-weight: 600;">Nagpur</span>
            </div>
          </div>
        `;

        marker.bindPopup(popupContent).openPopup();
      });

      markersGroup.addLayer(marker);
    });

    // If user marker exists, also include it in bounds when fitting
    if (userCoords) {
      bounds.extend([userCoords.lat, userCoords.lng]);
    }

    // Fit bounds if we have events and not actively dragged
    if (filteredEvents.length > 0 && map && !selectedMapEvent) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    }
  }, [filteredEvents, selectedMapEvent, userCoords]);

  // Center on Nagpur
  const handleResetToNagpur = () => {
    if (!leafletMapRef.current) return;
    const nagpurCenter: [number, number] = [21.1458, 79.0882];
    leafletMapRef.current.setView(nagpurCenter, 12, { animate: true });
    setSelectedMapEvent(null);
  };

  const handleOpenVenuePlan = (evt: EventData) => {
    setSelectedEventId(evt.id);
    setCurrentView('map');
  };

  const handleOpenAttendeeGuide = (evt: EventData) => {
    setSelectedEventId(evt.id);
    setCurrentView('attendee');
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-0 relative">
      {/* Top Header & Timing Filter Strip */}
      {showHeader && (
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
              <Compass className="w-4 h-4 text-emerald-600" />
              <span>Interactive Map & Live Geolocation · Nagpur</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-tight">
              Event Locations on Map & Your Live Position
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Locating Rojgar Mahakumbh, DNC Sports Festival, WHC Road, Chitnavis Centre, and Vasantrao Deshpande Hall
            </p>
          </div>

          {/* Timing Filters Segmented Control */}
          <div className="flex items-center gap-1.5 p-1 bg-white border border-slate-200 rounded-lg shadow-xs self-start md:self-auto text-xs">
            <button
              onClick={() => setActiveTimingFilter('all')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                activeTimingFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Venues ({events.length})
            </button>
            <button
              onClick={() => setActiveTimingFilter('ongoing')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTimingFilter === 'ongoing'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-red-700'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping inline-block" />
              <span>Ongoing ({ongoingCount})</span>
            </button>
            <button
              onClick={() => setActiveTimingFilter('upcoming')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                activeTimingFilter === 'upcoming'
                  ? 'bg-sky-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-sky-800'
              }`}
            >
              Upcoming ({upcomingCount})
            </button>
          </div>
        </div>
      )}

      {/* Map Canvas and Floating Controls */}
      <div className="relative w-full">
        {/* Leaflet Map DOM Element */}
        <div ref={mapContainerRef} className={`w-full ${height} bg-slate-100 z-0`} />

        {/* Floating Controls Overlay (Top Left) */}
        <div className="absolute top-3 left-3 z-[1000] flex flex-wrap items-center gap-2 pointer-events-none">
          {/* Live Location Dot Button */}
          <button
            onClick={() => handleGetLocation(true)}
            className="pointer-events-auto px-3 py-2 bg-white/95 hover:bg-white text-slate-800 rounded-lg shadow-md border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all focus:ring-2 focus:ring-blue-500"
            title="Locate me and show my current position with a blue dot"
          >
            <Locate className={`w-4 h-4 text-blue-600 ${isLocating ? 'animate-spin' : ''}`} />
            <span>{isLocating ? 'Locating...' : userCoords ? 'Re-center on My Dot' : 'Show My Location (Blue Dot)'}</span>
            {userCoords && (
              <span className="w-2 h-2 rounded-full bg-blue-600 inline-block ml-0.5" />
            )}
          </button>

          {/* Reset to Nagpur Overview Button */}
          <button
            onClick={handleResetToNagpur}
            className="pointer-events-auto px-3 py-2 bg-white/95 hover:bg-white text-slate-700 rounded-lg shadow-md border border-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all"
            title="Fit map view to all Nagpur events"
          >
            <Crosshair className="w-4 h-4 text-emerald-600" />
            <span>Nagpur Overview</span>
          </button>


        </div>

        {/* Location Notice / Error Banner if denied */}
        {locationError && (
          <div className="absolute top-16 left-3 right-3 sm:right-auto z-[1000] bg-amber-900/90 text-amber-100 text-xs p-2.5 rounded-lg border border-amber-700 shadow-lg flex items-center justify-between gap-3 pointer-events-auto">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-300 shrink-0" />
              <span>{locationError}</span>
            </div>
            <button
              onClick={() => setLocationError(null)}
              className="text-amber-300 hover:text-white font-bold p-0.5"
            >
              ✕
            </button>
          </div>
        )}

        {/* Live Location Active Indicator (Top Right Under Zoom) */}
        {userCoords && (
          <div className="absolute top-20 right-3 z-[1000] bg-blue-900/90 text-white px-3 py-1.5 rounded-lg shadow-md border border-blue-700 text-xs flex items-center gap-2 pointer-events-auto">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span>
            </span>
            <span className="text-[11px] font-medium">
              Live Location Dot Active ({userCoords.lat.toFixed(3)}°, {userCoords.lng.toFixed(3)}°)
            </span>
          </div>
        )}

        {/* Bottom Legend Overlay */}
        <div className="absolute bottom-4 left-4 z-[1000] bg-white/95 backdrop-blur-md px-3.5 py-2.5 rounded-lg border border-slate-200 shadow-md text-xs space-y-1.5 pointer-events-auto">
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5 font-semibold text-slate-800">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 inline-block shadow-xs" />
              <span>Ongoing (29 Sept)</span>
            </span>
            <span className="flex items-center gap-1.5 font-semibold text-slate-800">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-600 inline-block shadow-xs" />
              <span>Upcoming</span>
            </span>
            <span className="flex items-center gap-1.5 font-semibold text-blue-700">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block shadow-xs" />
              <span>Your Location Dot</span>
            </span>
          </div>
          <div className="text-[10px] text-slate-500">
            Nagpur, Maharashtra · Real Street Coordinates · Tap any marker
          </div>
        </div>
      </div>

      {/* Selected Location Card Panel (Bottom Drawer) */}
      {selectedMapEvent && (
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-emerald-50/40 animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                    selectedMapEvent.timingStatus === 'ongoing'
                      ? 'bg-red-100 text-red-800 border-red-200'
                      : 'bg-sky-100 text-sky-800 border-sky-200'
                  }`}
                >
                  {selectedMapEvent.timingStatus === 'ongoing' ? '● Ongoing Live' : '○ Upcoming Event'}
                </span>
                <span className="text-xs text-slate-600 font-medium">
                  {selectedMapEvent.category}
                </span>
                {userCoords && (
                  <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    📍 {getDistanceKm(selectedMapEvent.coordinates.lat, selectedMapEvent.coordinates.lng)} from you
                  </span>
                )}
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {selectedMapEvent.title}
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                <strong>Venue:</strong> {selectedMapEvent.venue} · <strong>Date:</strong> {selectedMapEvent.date} ({selectedMapEvent.timeRange})
              </p>
            </div>

            {/* Direct Actions */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => handleOpenVenuePlan(selectedMapEvent)}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
              >
                <span>Inspect Venue Safety Map</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleOpenAttendeeGuide(selectedMapEvent)}
                className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-semibold rounded-lg transition-colors"
              >
                Attendee Guide
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Attribution footer */}
      <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-400 flex items-center justify-between">
        <span>Nagpur Event Mapping & Flow Intelligence · CrowdSafe</span>
        <span>OpenStreetMap & CartoDB tiles · GPS Geolocation</span>
      </div>
    </div>
  );
};
