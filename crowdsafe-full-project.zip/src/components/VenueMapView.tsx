import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { InteractiveMap } from './InteractiveMap';
import { GoogleMapsView } from './GoogleMapsView';
import { Compass, MapPin, Layers, Map, Grid } from 'lucide-react';

export const VenueMapView: React.FC = () => {
  const {
    currentEvent,
    events,
    setSelectedEventId,
    selectedZoneId,
    setSelectedZoneId,
    setIsRouteModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'google-map' | 'venue-density'>('google-map');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
            <Compass className="w-4 h-4 text-emerald-600" />
            <span>Interactive Navigation & Maps · Nagpur</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {currentEvent.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            {currentEvent.venue} · {currentEvent.city} · <strong>Date:</strong> {currentEvent.date}
          </p>
        </div>

        {/* Event selector & Calm Route CTA */}
        <div className="flex flex-wrap items-center gap-2.5">
          <select
            value={currentEvent.id}
            onChange={(e) => setSelectedEventId(e.target.value)}
            className="px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            {events.map((evt) => (
              <option key={evt.id} value={evt.id}>
                {evt.timingStatus === 'ongoing' ? '● [Ongoing] ' : '○ [Upcoming] '}
                {evt.title} ({evt.venue.split(',')[0]})
              </option>
            ))}
          </select>

          <button
            onClick={() => setIsRouteModalOpen(true)}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Find Calmed Route</span>
          </button>
        </div>
      </div>

      {/* Map Switcher Tabs */}
      <div className="flex items-center p-1 bg-white border border-slate-200 rounded-lg shadow-xs text-xs self-start gap-1">
        <button
          onClick={() => setActiveTab('google-map')}
          className={`flex-1 sm:flex-none px-4 py-2 rounded-md font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeTab === 'google-map'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Map className="w-4 h-4 text-emerald-400" />
          <span>Google Map (Locate 7 Nagpur Venues)</span>
        </button>

        <button
          onClick={() => setActiveTab('venue-density')}
          className={`flex-1 sm:flex-none px-4 py-2 rounded-md font-semibold transition-colors flex items-center justify-center gap-2 ${
            activeTab === 'venue-density'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" />
          <span>{currentEvent.title} Sector Flow & Egress Layout</span>
        </button>
      </div>

      {/* Google Map View */}
      {activeTab === 'google-map' && (
        <div className="space-y-4">
          <GoogleMapsView
            showHeader={true}
            height="h-[520px] sm:h-[600px]"
            onSelectEvent={(evt) => setSelectedEventId(evt.id)}
            selectedEventId={currentEvent.id}
          />
        </div>
      )}

      {/* Venue Crowd Density Layout */}
      {activeTab === 'venue-density' && (
        <div className="space-y-6">
          <InteractiveMap interactive={true} compact={false} showZonePanel={true} />

          {/* Zone Quick-Jump Selector Row */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
            <h2 className="text-sm font-bold text-slate-900">
              {currentEvent.title} — Venue Sectors & Density Ratings
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {currentEvent.zones.map((zone) => {
                const isSelected = zone.id === selectedZoneId;
                return (
                  <button
                    key={zone.id}
                    onClick={() => setSelectedZoneId(zone.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'bg-emerald-50/70 border-emerald-300 ring-2 ring-emerald-500'
                        : 'bg-slate-50/50 border-slate-200 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-mono font-bold text-slate-700 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        {zone.code}
                      </span>
                      <span
                        className={`font-semibold capitalize text-[11px] ${
                          zone.densityLevel === 'critical'
                            ? 'text-red-600'
                            : zone.densityLevel === 'high'
                            ? 'text-amber-600'
                            : 'text-emerald-700'
                        }`}
                      >
                        {zone.densityLevel} ({zone.densityPerM2} ppl/m²)
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-slate-900 truncate">{zone.name}</h3>
                    <p className="text-[11px] text-slate-500 mt-1 truncate">
                      Occupancy: {zone.currentOccupancy.toLocaleString()} / {zone.licensedCapacity.toLocaleString()}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
