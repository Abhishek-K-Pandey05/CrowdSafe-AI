import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { InteractiveMap } from './InteractiveMap';
import { GoogleMapsView } from './GoogleMapsView';
import { PredictiveCrowdAnalysis } from './PredictiveCrowdAnalysis';
import { LiveWebcamCVMonitor } from './LiveWebcamCVMonitor';
import {
  LayoutDashboard,
  ShieldCheck,
  AlertTriangle,
  Users,
  Activity,
  ArrowRight,
  Clock,
  Sparkles,
  Sliders,
  CheckCircle2,
  HeartPulse,
  DoorOpen,
  Radio,
  FileText,
  Plus,
  RefreshCw,
  Search,
  Filter,
  Check,
  UserCheck,
  Map,
  Layers,
  TrendingUp,
  Compass,
  Camera,
  Video,
} from 'lucide-react';
import { AlertSeverity, AlertStatus } from '../types';

export const ManagerDashboardView: React.FC = () => {
  const {
    currentEvent,
    events,
    setSelectedEventId,
    selectedZoneId,
    setSelectedZoneId,
    currentEventAlerts,
    setSelectedAlertId,
    acknowledgeAlert,
    assignAlert,
    resolveAlert,
    triggerSimulatedAlert,
    setIsThresholdsModalOpen,
    lastTelemetryTick,
    isSimulationActive,
    toggleSimulation,
    currentUser,
  } = useApp();

  const [activeMapTab, setActiveMapTab] = useState<'venue-density' | 'geographic-map' | 'webcam-cv'>('venue-density');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const occupancyPct = Math.round(
    (currentEvent.estimatedOccupancy / currentEvent.totalCapacity) * 100
  );

  const peakZone = useMemo(() => {
    return [...currentEvent.zones].sort((a, b) => b.densityPerM2 - a.densityPerM2)[0];
  }, [currentEvent]);

  const filteredAlerts = useMemo(() => {
    return currentEventAlerts
      .filter((a) => {
        const matchesSev = severityFilter === 'all' || a.severity === severityFilter;
        const matchesStat = statusFilter === 'all' || a.status === statusFilter;
        return matchesSev && matchesStat;
      })
      .sort((a, b) => {
        // Prioritize critical and high
        const order = { critical: 4, high: 3, moderate: 2, advisory: 1 };
        return order[b.severity] - order[a.severity];
      });
  }, [currentEventAlerts, severityFilter, statusFilter]);

  const activeAlertsCount = currentEventAlerts.filter((a) => a.status !== 'resolved').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Operations Header */}
      <div className="bg-slate-900 text-white rounded-xl p-5 sm:p-6 shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Safety Operations Command Center</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300 font-mono">Live Telemetry Feed</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Event Manager Safety Portal
            </h1>
            {/* Event Selector Dropdown */}
            <select
              value={currentEvent.id}
              onChange={(e) => setSelectedEventId(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-white text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {events.map((evt) => (
                <option key={evt.id} value={evt.id}>
                  {evt.timingStatus === 'ongoing' ? '● [Live] ' : '○ [Upcoming] '}
                  {evt.title} ({evt.venue.split(',')[0]})
                </option>
              ))}
            </select>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Active Duty Lead: <strong>{currentUser ? currentUser.name : 'Marcus Vance'}</strong> · Badge: {currentUser?.badgeNumber || 'CS-SAFETY-882'} · {currentEvent.venue}, Nagpur
          </p>
        </div>

        {/* Manager Action Bar: Trigger Simulation & Config Thresholds */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setActiveMapTab('webcam-cv')}
            className={`px-3.5 py-2 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 ${
              activeMapTab === 'webcam-cv'
                ? 'bg-emerald-600 ring-2 ring-emerald-400'
                : 'bg-emerald-700 hover:bg-emerald-800'
            }`}
            title="Launch live webcam or simulated optical feed with OpenCV detection"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>OpenCV WebCam Feed</span>
          </button>

          <button
            onClick={triggerSimulatedAlert}
            className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            title="Simulate sudden influx to test dispatch workflow"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Trigger Test Bottleneck</span>
          </button>

          <button
            onClick={() => setIsThresholdsModalOpen(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5 text-emerald-400" />
            <span>Configure Thresholds</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Venue Occupancy vs Place Capacity */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold uppercase tracking-wider">Place Capacity & Load</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {currentEvent.estimatedOccupancy.toLocaleString()}
            </span>
            <span className="text-xs font-semibold text-slate-700">
              / {currentEvent.totalCapacity.toLocaleString()} ({occupancyPct}%)
            </span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-1.5 rounded-full ${
                occupancyPct > 80 ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${occupancyPct}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Peak Zone Density */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold uppercase tracking-wider">Peak Density Sector</span>
            <Activity className="w-4 h-4 text-slate-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {peakZone ? `${peakZone.densityPerM2} ppl/m²` : '—'}
            </span>
            <span className="text-xs font-semibold uppercase text-amber-600">
              {peakZone ? peakZone.code : 'NORM'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 truncate">
            {peakZone ? peakZone.name : 'All zones normal'}
          </p>
        </div>

        {/* Metric 3: Active Bottlenecks & Alerts */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold uppercase tracking-wider">Active Bottlenecks</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{activeAlertsCount}</span>
            <span className="text-xs text-slate-500">
              in queue ({currentEventAlerts.length} total)
            </span>
          </div>
          <p className="text-[11px] text-emerald-700 font-medium">
            {activeAlertsCount === 0 ? 'All zones flowing freely' : 'Action items require triage'}
          </p>
        </div>

        {/* Metric 4: Stewards on Duty */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold uppercase tracking-wider">Steward Units</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {currentEvent.stewardTeams.length} Teams
            </span>
            <span className="text-xs text-emerald-700 font-semibold">100% Deployed</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Radio linked across perimeter gates & aisles
          </p>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 🗺️ EVENT MANAGER MAP WITH CROWD DENSITY (VENUE SECTORS + GEOGRAPHIC MAP) */}
      {/* ========================================================================= */}
      <div className="space-y-4 bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-0.5">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span>Manager Spatial Telemetry & Density Heatmap</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              Live Map: {currentEvent.title}
            </h2>
            <p className="text-xs text-slate-500">
              Inspect sector crowd density, pedestrian velocity vectors, licensed capacities, and geographic location.
            </p>
          </div>

          {/* Map Layer Switcher */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs gap-1 self-start sm:self-auto">
            <button
              onClick={() => setActiveMapTab('venue-density')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                activeMapTab === 'venue-density'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              <span>Venue Crowd Density Layout</span>
            </button>

            <button
              onClick={() => setActiveMapTab('geographic-map')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                activeMapTab === 'geographic-map'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Map className="w-3.5 h-3.5 text-sky-400" />
              <span>Nagpur Geographic Map & GPS Dot</span>
            </button>

            <button
              onClick={() => setActiveMapTab('webcam-cv')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                activeMapTab === 'webcam-cv'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              <span>Live WebCam OpenCV Feed</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Venue Crowd Density Layout */}
        {activeMapTab === 'venue-density' && (
          <div className="space-y-4">
            <InteractiveMap interactive={true} compact={false} showZonePanel={true} />

            {/* Quick Sector Density Status Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
              {currentEvent.zones.map((zone) => {
                const isSelected = zone.id === selectedZoneId;
                const occPercent = Math.round((zone.currentOccupancy / zone.licensedCapacity) * 100);

                return (
                  <button
                    key={zone.id}
                    onClick={() => setSelectedZoneId(zone.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'bg-emerald-50/70 border-emerald-300 ring-2 ring-emerald-500'
                        : 'bg-slate-50/50 border-slate-200 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-mono font-bold text-slate-700 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        {zone.code}
                      </span>
                      <span
                        className={`font-semibold capitalize text-[11px] ${
                          zone.densityLevel === 'critical'
                            ? 'text-red-600'
                            : zone.densityLevel === 'high'
                            ? 'text-amber-600'
                            : 'text-emerald-700'
                        }`}
                      >
                        {zone.densityLevel} ({zone.densityPerM2} ppl/m²)
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-slate-900 truncate">{zone.name}</h3>
                    <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Occupancy:</span>
                      <span className="font-semibold text-slate-800">
                        {zone.currentOccupancy.toLocaleString()} / {zone.licensedCapacity.toLocaleString()} ({occPercent}%)
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Geographic Map */}
        {activeMapTab === 'geographic-map' && (
          <div className="space-y-2">
            <GoogleMapsView
              showHeader={false}
              height="h-[460px] sm:h-[520px]"
              selectedEventId={currentEvent.id}
            />
          </div>
        )}

        {/* Tab 3: OpenCV WebCam Feed */}
        {activeMapTab === 'webcam-cv' && (
          <div className="space-y-2">
            <LiveWebcamCVMonitor />
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 🔮 PREDICTIVE ANALYSIS: WHAT CAN HAPPEN & PLACE OVERCROWDING FORECASTS */}
      {/* ========================================================================= */}
      <PredictiveCrowdAnalysis event={currentEvent} />

      {/* ========================================================================= */}
      {/* 🚨 BOTTLENECK DETECTION & ALERT TRIAGE QUEUE */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Bottleneck Detection & Alert Triage Queue
            </h2>
            <p className="text-xs text-slate-500">
              Automated anomaly detection across rising density, opposing flow friction, and blocked egress
            </p>
          </div>

          {/* Severity & Status Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical Only</option>
              <option value="high">High Only</option>
              <option value="moderate">Moderate Only</option>
              <option value="advisory">Advisory Only</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="acknowledged">Acknowledged</option>
              <option value="assigned">Assigned</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>
        </div>

        {/* Alerts List */}
        {filteredAlerts.length === 0 ? (
          <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500 space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
            <p className="font-semibold text-slate-800">No active alerts matching your criteria</p>
            <p className="text-slate-400">All venue sectors are operating within calibrated thresholds.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-5 rounded-xl border transition-all ${
                  alert.severity === 'critical'
                    ? 'bg-red-50/50 border-red-200 ring-1 ring-red-200'
                    : alert.severity === 'high'
                    ? 'bg-amber-50/50 border-amber-200'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded border ${
                          alert.severity === 'critical'
                            ? 'bg-red-100 text-red-800 border-red-300'
                            : alert.severity === 'high'
                            ? 'bg-amber-100 text-amber-800 border-amber-300'
                            : 'bg-blue-100 text-blue-800 border-blue-300'
                        }`}
                      >
                        {alert.severity}
                      </span>
                      <span className="font-semibold text-xs text-slate-800">
                        {alert.zoneName}
                      </span>
                      <span className="text-xs text-slate-400">· {alert.timestamp}</span>
                      <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                        {alert.confidence}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 leading-snug">
                      {alert.title}
                    </h3>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {alert.observedChange}
                    </p>

                    <div className="bg-white/80 p-3 rounded-lg border border-slate-200/80 text-xs space-y-1">
                      <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Recommended Proactive Intervention:</span>
                      </div>
                      <p className="text-slate-700">{alert.recommendedAction}</p>
                    </div>

                    {alert.assignedTo && (
                      <p className="text-xs text-emerald-800 font-medium">
                        ✓ Assigned to: <strong>{alert.assignedTo}</strong>
                      </p>
                    )}
                  </div>

                  {/* Alert Action Buttons */}
                  <div className="flex flex-wrap sm:flex-col gap-2 shrink-0">
                    {alert.status === 'active' && (
                      <button
                        onClick={() => acknowledgeAlert(alert.id)}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-md shadow-xs transition-colors"
                      >
                        Acknowledge
                      </button>
                    )}

                    {alert.status !== 'resolved' && (
                      <button
                        onClick={() =>
                          assignAlert(alert.id, currentEvent.stewardTeams[0]?.name || 'Rapid Response Unit')
                        }
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Dispatch Stewards</span>
                      </button>
                    )}

                    {alert.status !== 'resolved' && (
                      <button
                        onClick={() => resolveAlert(alert.id, 'Flow restored by steward action')}
                        className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-medium rounded-md transition-colors"
                      >
                        Mark Resolved
                      </button>
                    )}

                    {alert.status === 'resolved' && (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 text-center">
                        ✓ Resolved
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
