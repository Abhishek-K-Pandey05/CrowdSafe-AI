import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Compass,
  ArrowRight,
  Footprints,
  Accessibility,
  CheckCircle2,
  ShieldCheck,
  MapPin,
  Clock,
} from 'lucide-react';

export const RouteFinderModal: React.FC = () => {
  const {
    isRouteModalOpen,
    setIsRouteModalOpen,
    currentEvent,
    selectedZoneId,
    findCalmRoute,
    setActiveRoute,
    setCurrentView,
  } = useApp();

  const [originId, setOriginId] = useState<string>(selectedZoneId || currentEvent.zones[0]?.id || '');
  const [destinationId, setDestinationId] = useState<string>(
    currentEvent.zones.find((z) => z.id !== (selectedZoneId || currentEvent.zones[0]?.id))?.id || currentEvent.zones[0]?.id || ''
  );
  const [calculatedRoute, setCalculatedRoute] = useState<ReturnType<typeof findCalmRoute>>(null);

  React.useEffect(() => {
    if (!currentEvent.zones.find((z) => z.id === originId)) {
      setOriginId(currentEvent.zones[0]?.id || '');
    }
    if (!currentEvent.zones.find((z) => z.id === destinationId)) {
      setDestinationId(currentEvent.zones[1]?.id || currentEvent.zones[0]?.id || '');
    }
  }, [currentEvent, originId, destinationId]);

  if (!isRouteModalOpen) return null;

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    if (originId === destinationId) return;
    const route = findCalmRoute(originId, destinationId);
    setCalculatedRoute(route);
  };

  const handleApplyRoute = () => {
    if (calculatedRoute) {
      setActiveRoute(calculatedRoute);
      setIsRouteModalOpen(false);
      setCurrentView('map');
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="route-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="relative bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h2 id="route-modal-title" className="text-base font-bold text-slate-900">
                Find a Less-Crowded Route
              </h2>
              <p className="text-xs text-slate-500">Bypass high-density bottlenecks with gentle perimeter paths</p>
            </div>
          </div>
          <button
            onClick={() => setIsRouteModalOpen(false)}
            aria-label="Close route finder"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selection Form */}
        <form onSubmit={handleCalculate} className="py-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                <span>Starting Zone / Gate</span>
              </label>
              <select
                value={originId}
                onChange={(e) => {
                  setOriginId(e.target.value);
                  setCalculatedRoute(null);
                }}
                className="w-full px-3 py-2 rounded-md border border-slate-300 text-xs bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {currentEvent.zones.map((z) => (
                  <option key={z.id} value={z.id}>
                    {z.name} ({z.densityPerM2} ppl/m²)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                <span>Destination</span>
              </label>
              <select
                value={destinationId}
                onChange={(e) => {
                  setDestinationId(e.target.value);
                  setCalculatedRoute(null);
                }}
                className="w-full px-3 py-2 rounded-md border border-slate-300 text-xs bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {currentEvent.zones.map((z) => (
                  <option key={z.id} value={z.id} disabled={z.id === originId}>
                    {z.name} ({z.densityPerM2} ppl/m²)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors flex items-center justify-center gap-2"
          >
            <Compass className="w-4 h-4" />
            <span>Calculate Calmed Walking Route</span>
          </button>
        </form>

        {/* Calculated Result Display */}
        {calculatedRoute && (
          <div className="mt-2 p-4 rounded-lg bg-emerald-50/70 border border-emerald-200 text-xs space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-sm">{calculatedRoute.title}</span>
              <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-white px-2 py-0.5 rounded border border-emerald-200">
                <Clock className="w-3 h-3" />
                <span>~{calculatedRoute.estimatedMinutes} min walk</span>
              </span>
            </div>

            <div className="flex items-center gap-4 text-[11px] text-slate-600">
              <span className="flex items-center gap-1">
                <Accessibility className="w-3.5 h-3.5 text-violet-700" />
                <span>Step-free & wheelchair accessible</span>
              </span>
              <span>·</span>
              <span className="text-emerald-700 font-medium">Avg density: {calculatedRoute.averageDensity} ppl/m²</span>
            </div>

            <div className="space-y-1.5 pt-1">
              <p className="font-semibold text-slate-800 text-[11px] uppercase tracking-wider">Step-by-Step Wayfinding:</p>
              <ol className="space-y-1 list-decimal list-inside text-slate-700">
                {calculatedRoute.instructions.map((ins, i) => (
                  <li key={i} className="leading-relaxed">
                    {ins}
                  </li>
                ))}
              </ol>
            </div>

            <div className="pt-2 border-t border-emerald-200/80 flex items-center justify-between">
              <p className="text-[11px] text-emerald-900 italic">
                "{calculatedRoute.keySafetyTip}"
              </p>
              <button
                type="button"
                onClick={handleApplyRoute}
                className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded font-medium shadow-xs transition-colors shrink-0"
              >
                Display on Map
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
