/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { BackgroundFlow } from './components/BackgroundFlow';
import { HomeView } from './components/HomeView';
import { EventExplorerView } from './components/EventExplorerView';
import { VenueMapView } from './components/VenueMapView';
import { AttendeeView } from './components/AttendeeView';
import { ManagerDashboardView } from './components/ManagerDashboardView';
import { MobileCameraBroadcasterView } from './components/MobileCameraBroadcasterView';
import { AuthModal } from './components/AuthModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { SettingsModal } from './components/SettingsModal';
import { ThresholdsModal } from './components/ThresholdsModal';
import { RouteFinderModal } from './components/RouteFinderModal';
import { AlertDetailModal } from './components/AlertDetailModal';

const AppContent: React.FC = () => {
  const { currentView, settings } = useApp();

  return (
    <div
      className={`min-h-screen flex flex-col bg-slate-100/60 text-slate-900 transition-colors ${
        settings.highContrast ? 'contrast-125' : ''
      }`}
    >
      {/* Dynamic 3D-inspired subtle flow canvas background */}
      <BackgroundFlow />

      {/* Main Responsive Header Navigation */}
      <Navbar />

      {/* Main View Router */}
      <main className="flex-1 relative z-10">
        {currentView === 'home' && <HomeView />}
        {currentView === 'events' && <EventExplorerView />}
        {currentView === 'map' && <VenueMapView />}
        {currentView === 'attendee' && <AttendeeView />}
        {currentView === 'dashboard' && <ManagerDashboardView />}
        {currentView === 'mobile-camera' && <MobileCameraBroadcasterView />}
      </main>

      {/* Global Modals & Drawers */}
      <AuthModal />
      <NotificationDrawer />
      <SettingsModal />
      <ThresholdsModal />
      <RouteFinderModal />
      <AlertDetailModal />

      {/* Trustworthy Safety & Emergency Footer */}
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
