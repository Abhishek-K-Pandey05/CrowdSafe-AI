import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  EventData,
  Zone,
  Alert,
  AlertStatus,
  AppNotification,
  UserProfile,
  UserSettings,
  ManagerThresholds,
  UserLocation,
  CalmedRoute,
  CrowdDensityLevel,
} from '../types';
import { MOCK_EVENTS, MOCK_ALERTS, MOCK_NOTIFICATIONS, DEMO_USERS, INITIAL_THRESHOLDS } from '../data/mockEvents';

export type AppView = 'home' | 'events' | 'map' | 'attendee' | 'dashboard' | 'mobile-camera';

interface AppContextType {
  // Navigation & View
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  selectedEventId: string;
  setSelectedEventId: (id: string) => void;
  selectedZoneId: string | null;
  setSelectedZoneId: (id: string | null) => void;
  selectedAlertId: string | null;
  setSelectedAlertId: (id: string | null) => void;

  // Active Data
  events: EventData[];
  currentEvent: EventData;
  currentZone: Zone | null;
  alerts: Alert[];
  currentEventAlerts: Alert[];
  notifications: AppNotification[];
  unreadNotificationCount: number;

  // User & Auth
  currentUser: UserProfile | null;
  isManager: boolean;
  isAttendee: boolean;
  loginAsAttendee: () => void;
  loginAsManager: () => void;
  loginWithCustom: (name: string, email: string, role: 'attendee' | 'manager') => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authDefaultTab: 'attendee' | 'manager';
  openAuthModal: (defaultTab?: 'attendee' | 'manager') => void;

  // Alert Workflows
  acknowledgeAlert: (alertId: string, note?: string) => void;
  assignAlert: (alertId: string, teamName: string) => void;
  addAlertNote: (alertId: string, noteText: string) => void;
  resolveAlert: (alertId: string, resolutionNote: string) => void;
  triggerSimulatedAlert: () => void;

  // Thresholds
  thresholds: ManagerThresholds;
  updateThresholds: (newThresholds: Partial<ManagerThresholds>) => void;
  isThresholdsModalOpen: boolean;
  setIsThresholdsModalOpen: (open: boolean) => void;

  // Settings
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  isSettingsModalOpen: boolean;
  setIsSettingsModalOpen: (open: boolean) => void;

  // Location & Geolocation
  userLocation: UserLocation;
  requestUserLocation: () => void;
  stopSharingLocation: () => void;
  setManualLocation: (mapX: number, mapY: number, zoneId?: string) => void;

  // Pathfinding / Route Calmer
  findCalmRoute: (originZoneId: string, targetZoneId: string) => CalmedRoute | null;
  activeRoute: CalmedRoute | null;
  setActiveRoute: (route: CalmedRoute | null) => void;
  isRouteModalOpen: boolean;
  setIsRouteModalOpen: (open: boolean) => void;

  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  clearNotification: (id: string) => void;
  isNotificationDrawerOpen: boolean;
  setIsNotificationDrawerOpen: (open: boolean) => void;

  // Real-time Simulation Feed
  isSimulationActive: boolean;
  toggleSimulation: () => void;
  lastTelemetryTick: Date;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (
        params.get('view') === 'mobile-camera' ||
        window.location.hash.includes('mobile-camera') ||
        window.location.pathname.includes('mobile-camera')
      ) {
        return 'mobile-camera';
      }
    }
    return 'home';
  });
  const [selectedEventId, setSelectedEventId] = useState<string>('evt-rojgar-mahakumbh-2026');
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>('z-sym-hallA');
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);

  const [events, setEvents] = useState<EventData[]>(MOCK_EVENTS);
  const [alerts, setAlerts] = useState<Alert[]>(MOCK_ALERTS);
  const [notifications, setNotifications] = useState<AppNotification[]>(MOCK_NOTIFICATIONS);

  // Authentication default: Attendee Maya Chen for immediate demo usability, or guest
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(DEMO_USERS.attendee);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authDefaultTab, setAuthDefaultTab] = useState<'attendee' | 'manager'>('attendee');

  const [thresholds, setThresholds] = useState<ManagerThresholds>(INITIAL_THRESHOLDS);
  const [isThresholdsModalOpen, setIsThresholdsModalOpen] = useState<boolean>(false);

  const [settings, setSettings] = useState<UserSettings>({
    stepFreePreferred: false,
    sensoryQuietAlerts: false,
    highContrast: false,
    reducedMotion: false,
    notificationSound: true,
    notificationVibrate: true,
    autoRefreshRate: 10,
  });
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);

  const [userLocation, setUserLocation] = useState<UserLocation>({
    active: true,
    isSimulated: true,
    mapX: 42,
    mapY: 18,
    nearestZoneId: 'z-sym-gate1',
    permissionState: 'prompt',
  });

  const [activeRoute, setActiveRoute] = useState<CalmedRoute | null>(null);
  const [isRouteModalOpen, setIsRouteModalOpen] = useState<boolean>(false);
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState<boolean>(false);

  const [isSimulationActive, setIsSimulationActive] = useState<boolean>(true);
  const [lastTelemetryTick, setLastTelemetryTick] = useState<Date>(new Date());

  const currentEvent = events.find((e) => e.id === selectedEventId) || events[0];
  const currentZone = currentEvent.zones.find((z) => z.id === selectedZoneId) || null;
  const currentEventAlerts = alerts.filter((a) => a.eventId === selectedEventId);

  const isManager = currentUser?.role === 'manager';
  const isAttendee = currentUser?.role === 'attendee';

  const unreadNotificationCount = notifications.filter((n) => {
    if (n.read) return false;
    if (n.targetRole === 'all') return true;
    if (n.targetRole === 'manager' && isManager) return true;
    if (n.targetRole === 'attendee' && !isManager) return true;
    return false;
  }).length;

  const openAuthModal = useCallback((defaultTab: 'attendee' | 'manager' = 'attendee') => {
    setAuthDefaultTab(defaultTab);
    setIsAuthModalOpen(true);
  }, []);

  const loginAsAttendee = useCallback(() => {
    setCurrentUser(DEMO_USERS.attendee);
    setIsAuthModalOpen(false);
  }, []);

  const loginAsManager = useCallback(() => {
    setCurrentUser(DEMO_USERS.manager);
    setIsAuthModalOpen(false);
  }, []);

  const loginWithCustom = useCallback((name: string, email: string, role: 'attendee' | 'manager') => {
    const initials = name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || (role === 'manager' ? 'MG' : 'AT');

    setCurrentUser({
      id: `usr-${Date.now()}`,
      name,
      email,
      role,
      roleTitle: role === 'manager' ? 'Event Safety Officer' : 'Event Attendee',
      avatarInitials: initials,
      badgeNumber: role === 'manager' ? `SO-${Math.floor(100 + Math.random() * 900)}` : undefined,
    });
    setIsAuthModalOpen(false);
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    if (currentView === 'dashboard') {
      setCurrentView('events');
    }
  }, [currentView]);

  const updateThresholds = useCallback((newThresholds: Partial<ManagerThresholds>) => {
    setThresholds((prev) => ({ ...prev, ...newThresholds }));
  }, []);

  const updateSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  // Alert actions
  const acknowledgeAlert = useCallback((alertId: string, note?: string) => {
    const author = currentUser ? currentUser.name : 'Duty Safety Officer';
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id !== alertId) return a;
        const newHist = [
          ...a.statusHistory,
          { status: 'acknowledged' as AlertStatus, by: author, time: now, note: note || 'Alert acknowledged by dispatch' },
        ];
        return {
          ...a,
          status: 'acknowledged',
          statusHistory: newHist,
        };
      })
    );
  }, [currentUser]);

  const assignAlert = useCallback((alertId: string, teamName: string) => {
    const author = currentUser ? currentUser.name : 'Duty Safety Officer';
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id !== alertId) return a;
        const newHist = [
          ...a.statusHistory,
          { status: 'assigned' as AlertStatus, by: author, time: now, note: `Dispatched response unit: ${teamName}` },
        ];
        return {
          ...a,
          status: 'assigned',
          assignedTo: teamName,
          statusHistory: newHist,
        };
      })
    );
  }, [currentUser]);

  const addAlertNote = useCallback((alertId: string, noteText: string) => {
    if (!noteText.trim()) return;
    const author = currentUser ? currentUser.name : 'Safety Officer';
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id !== alertId) return a;
        return {
          ...a,
          internalNotes: [
            ...a.internalNotes,
            { id: `note-${Date.now()}`, author, time: now, text: noteText.trim() },
          ],
        };
      })
    );
  }, [currentUser]);

  const resolveAlert = useCallback((alertId: string, resolutionNote: string) => {
    const author = currentUser ? currentUser.name : 'Duty Safety Officer';
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.id !== alertId) return a;
        const newHist = [
          ...a.statusHistory,
          { status: 'resolved' as AlertStatus, by: author, time: now, note: resolutionNote || 'Bottleneck dispersed. Flow restored.' },
        ];
        return {
          ...a,
          status: 'resolved',
          statusHistory: newHist,
        };
      })
    );
  }, [currentUser]);

  const triggerSimulatedAlert = useCallback(() => {
    const activeEvt = events.find((e) => e.id === selectedEventId) || events[0];
    const targetZone = activeEvt.zones[0] || { id: 'z-default', name: 'Main Concourse' };

    const newAlert: Alert = {
      id: `alt-sim-${Date.now()}`,
      eventId: selectedEventId,
      zoneId: targetZone.id,
      zoneName: targetZone.name,
      severity: 'high',
      category: 'rising_density',
      title: `Sudden Crowd Inflow: Peak Shift at ${targetZone.name}`,
      observedChange: 'Rapid surge from perimeter transit arrival. Local sector density jumped by 1.2 persons/m² in 4 minutes.',
      timestamp: 'Just now',
      confidence: 'Nagpur Smart Telemetry Sensor Array #04 (96% confidence)',
      sensorType: 'optical',
      status: 'active',
      recommendedAction: `Deploy available stewards to ${targetZone.name} to meter entry turnstiles and preserve clear egress aisles.`,
      internalNotes: [],
      statusHistory: [
        { status: 'active', by: 'Automated Threshold Engine', time: 'Just now', note: 'Triggered via manager safety threshold test' },
      ],
    };

    setAlerts((prev) => [newAlert, ...prev]);

    // Push notification as well
    const newNotif: AppNotification = {
      id: `notif-sim-${Date.now()}`,
      eventId: selectedEventId,
      zoneId: targetZone.id,
      alertId: newAlert.id,
      targetRole: 'all',
      severity: 'advisory',
      title: `${targetZone.name} Flow Alert`,
      message: `${targetZone.name} is experiencing heavy inflow. Stewards recommend using adjacent bypass avenues for comfortable walking.`,
      timestamp: 'Just now',
      read: false,
      actionLabel: 'View Event Map',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  }, [selectedEventId, events]);

  // Geolocation handling
  const requestUserLocation = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setUserLocation((prev) => ({
        ...prev,
        permissionState: 'unsupported',
        error: 'Browser geolocation is not supported on this device. You can place your pin manually on the map.',
      }));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        // Find rough mapping onto venue coordinates for demo purposes
        setUserLocation({
          active: true,
          isSimulated: false,
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          // Place nicely on demo venue map
          mapX: 45,
          mapY: 25,
          nearestZoneId: 'z-main-lawn',
          permissionState: 'granted',
          error: undefined,
        });
      },
      (err) => {
        let msg = 'Location request was declined. You can manually tap anywhere on the map to set your location.';
        if (err.code === err.TIMEOUT) {
          msg = 'Location request timed out. You can tap on the venue map to place your position manually.';
        }
        setUserLocation((prev) => ({
          ...prev,
          active: false,
          permissionState: 'denied',
          error: msg,
        }));
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  }, []);

  const stopSharingLocation = useCallback(() => {
    setUserLocation({
      active: false,
      isSimulated: false,
      permissionState: 'prompt',
      mapX: undefined,
      mapY: undefined,
      nearestZoneId: undefined,
      error: undefined,
    });
  }, []);

  const setManualLocation = useCallback((mapX: number, mapY: number, zoneId?: string) => {
    setUserLocation({
      active: true,
      isSimulated: true,
      mapX,
      mapY,
      nearestZoneId: zoneId || 'z-west-concourse',
      permissionState: 'granted',
      error: undefined,
    });
  }, []);

  // Pathfinding Calmer
  const findCalmRoute = useCallback(
    (originZoneId: string, targetZoneId: string): CalmedRoute | null => {
      const origin = currentEvent.zones.find((z) => z.id === originZoneId);
      const target = currentEvent.zones.find((z) => z.id === targetZoneId);

      if (!origin || !target) return null;

      // Identify bypass zone (e.g. East Promenade is quietest)
      const bypassZone = currentEvent.zones.find((z) => z.code === 'WALK-E' || z.densityLevel === 'low') || currentEvent.zones[0];
      const isDirectQuiet = origin.densityLevel === 'low' && target.densityLevel === 'low';

      const pathZoneIds = isDirectQuiet
        ? [origin.id, target.id]
        : [origin.id, bypassZone.id, target.id];

      const avgDensity = 1.3;
      const crowdLevel: CrowdDensityLevel = avgDensity < 1.5 ? 'low' : 'moderate';

      return {
        id: `route-${originZoneId}-${targetZoneId}`,
        originZoneId,
        targetZoneId,
        pathZoneIds,
        title: `Calm Breeze Bypass via ${bypassZone.name}`,
        crowdLevel,
        averageDensity: avgDensity,
        estimatedMinutes: 6,
        isStepFree: true,
        instructions: [
          `Depart ${origin.name} heading towards the quieter outer perimeter.`,
          `Follow illuminated signage along ${bypassZone.name} to avoid the food queue bottleneck.`,
          `Arrive smoothly at ${target.name} via the wide, step-free accessway.`,
        ],
        keySafetyTip: 'Maintains at least 2.5 meters of open clearance around you the entire walk.',
      };
    },
    [currentEvent]
  );

  // Notification actions
  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const toggleSimulation = useCallback(() => {
    setIsSimulationActive((prev) => !prev);
  }, []);

  // Realistic gentle simulation tick every 9 seconds
  useEffect(() => {
    if (!isSimulationActive) return;

    const timer = setInterval(() => {
      setLastTelemetryTick(new Date());
      setEvents((prevEvents) =>
        prevEvents.map((evt) => {
          if (evt.id !== selectedEventId) return evt;

          const updatedZones = evt.zones.map((zone) => {
            // subtle realistic drift (+/- 15 people)
            const delta = Math.floor(Math.random() * 21) - 10;
            const newOcc = Math.max(100, Math.min(zone.licensedCapacity, zone.currentOccupancy + delta));
            const newDensity = Number((newOcc / (zone.licensedCapacity / 2.8)).toFixed(1));
            let level: CrowdDensityLevel = 'low';
            if (newDensity >= thresholds.criticalDensityPerM2) level = 'critical';
            else if (newDensity >= thresholds.highDensityPerM2) level = 'high';
            else if (newDensity >= 1.5) level = 'moderate';

            return {
              ...zone,
              currentOccupancy: newOcc,
              densityPerM2: newDensity,
              densityLevel: level,
            };
          });

          return {
            ...evt,
            zones: updatedZones,
          };
        })
      );
    }, 9000);

    return () => clearInterval(timer);
  }, [isSimulationActive, selectedEventId, thresholds]);

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedEventId,
        setSelectedEventId,
        selectedZoneId,
        setSelectedZoneId,
        selectedAlertId,
        setSelectedAlertId,
        events,
        currentEvent,
        currentZone,
        alerts,
        currentEventAlerts,
        notifications,
        unreadNotificationCount,
        currentUser,
        isManager,
        isAttendee,
        loginAsAttendee,
        loginAsManager,
        loginWithCustom,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authDefaultTab,
        openAuthModal,
        acknowledgeAlert,
        assignAlert,
        addAlertNote,
        resolveAlert,
        triggerSimulatedAlert,
        thresholds,
        updateThresholds,
        isThresholdsModalOpen,
        setIsThresholdsModalOpen,
        settings,
        updateSettings,
        isSettingsModalOpen,
        setIsSettingsModalOpen,
        userLocation,
        requestUserLocation,
        stopSharingLocation,
        setManualLocation,
        findCalmRoute,
        activeRoute,
        setActiveRoute,
        isRouteModalOpen,
        setIsRouteModalOpen,
        markNotificationRead,
        markAllNotificationsRead,
        clearNotification,
        isNotificationDrawerOpen,
        setIsNotificationDrawerOpen,
        isSimulationActive,
        toggleSimulation,
        lastTelemetryTick,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
