# CrowdSafe — Proactive Crowd Safety & Flow Management (Nagpur Events Edition)

CrowdSafe is an accessible, production-grade web application designed for large public events to help attendees navigate comfortably, avoid developing crush hazards, and provide event safety teams with proactive flow intelligence and dispatch workflows.

---

## 📍 Nagpur Events Lineup & Interactive Map

All event venues are mapped with precise coordinates centered on **Nagpur, Maharashtra**:

### 🔴 Ongoing Events (Live Today · 29 September 2026)
1. **Rojgar Mahakumbh** (29 September 2026)
   - **Venue:** Symbiosis Skill Development Centre, Wathoda, Nagpur
   - **Type:** Job Fair & Mega Vocational Skills Placement Drive
   - **Coordinates:** `21.1278° N, 79.1585° E`
   - **Capacity:** 25,000 (Current Estimated Attendance: 18,200)
   - **Active Safety Telemetry:** Gate 1 arrival flow management, interview pavilion queue metering, free chilled RO water stations.

2. **Dr. Panjabrao Deshmukh Memorial Inter-College Sports Festival** (29 Sept – 1 Oct 2026)
   - **Venue:** Dhanwate National College, Congress Nagar, Dhantoli, Nagpur
   - **Type:** Inter-College Athletic & Sports Championship
   - **Coordinates:** `21.1345° N, 79.0833° E`
   - **Capacity:** 12,000 (Current Estimated Attendance: 6,850)
   - **Active Safety Telemetry:** 400m track crossover pedestrian flow, shaded spectator gallery berms, sports medical tent.

### 📅 Upcoming Events (Nagpur Scheduled)
3. **Zighomes Property Agents Expo** (30 Sept 2026)
   - **Venue:** Bavane kunbi samaj sanskrutik Bhawan, Bapu Nagar, Nagpur
   - **Coordinates:** `21.1322° N, 79.1245° E`
4. **Comedy show: Kal Ki Chinta Nahi Karta** (3 Oct 2026)
   - **Venue:** Vasantrao Deshpande Hall, Civil Lines, Nagpur
   - **Coordinates:** `21.1528° N, 79.0736° E`
5. **Bollywood Dhamaka 2026** (4 Oct 2026)
   - **Venue:** WHC Road, Dharampeth, Nagpur
   - **Coordinates:** `21.1394° N, 79.0682° E`
6. **GoSwadeshi by GoCoop** (7 Oct 2026)
   - **Venue:** Chitnavis Centre, 56 Temple Road, Civil Lines, Nagpur
   - **Coordinates:** `21.1542° N, 79.0709° E`
7. **Love Death Aur Ketchup** (10 Oct 2026)
   - **Venue:** Vasantrao Deshpande Hall, Civil Lines, Nagpur
   - **Coordinates:** `21.1528° N, 79.0736° E`

---

## 🗺️ Interactive Map & Live Geolocation Features

- **Reliable Map Engine**: Built with Leaflet and CartoDB Voyager / OpenStreetMap street tiles, completely immune to API key domain or billing restrictions.
- **Pulsating Live User Location Dot**:
  - Click **"Show My Location (Blue Dot)"** to request browser geolocation and display a glowing, animated blue dot marking your current GPS position with an accuracy radius.
  - Automatically calculates real-time distance (in km or meters) from your location dot to every event venue.
- **Venue Markers**:
  - Ongoing events feature crimson pulsing live markers.
  - Upcoming events feature sky-blue scheduled markers.
  - Clicking any marker opens an interactive card showing event details, distance from your dot, and direct links to the venue layout.
- **Map Controls**:
  - **Re-center on My Dot**: Zooms straight into your live GPS location.
  - **Nagpur Overview**: Fits the map view to display all 7 event locations simultaneously.
  - **Map Tile Selector**: Toggle between CartoDB Voyager and OpenStreetMap Street views.

---

## 📱 Application Views & Capabilities

1. **Home (`/`)**:
   - Hero banner with safety philosophy: *"The safest event is one where risks are seen early and people can move freely."*
   - City-wide Nagpur interactive map.
   - Separate sections for **Ongoing Events (Live Today)** and **Upcoming Events**.
   - Notifications summary drawer and quick demo account logins.

2. **Explore Events**:
   - Separate, dedicated sections for **Ongoing Events (29 Sept 2026)** and **Upcoming Events**.
   - Search by keyword or venue (e.g. "Symbiosis", "Deshpande", "WHC Road").
   - Filter by event categories.
   - View mode switcher: **Map & List View**, **Google Map Only**, or **Cards Only**.

3. **Interactive Venue Map**:
   - Switch between **City-Wide Map (All 7 Venues)** and **Venue Sector Flow & Egress Layout**.
   - Sector-by-sector live density ratings (`ppl/m²`), capacity gauges, flow rates, and nearest emergency exits.
   - Step-free and accessible egress routes.

4. **Attendee Companion Guide**:
   - "Find a Less-Crowded Route" tool computing quiet perimeter bypass paths.
   - Nearby safe amenities directory: chilled drinking water spigots, accessible restrooms, first-aid posts, and emergency gates.
   - Emergency contacts and designated assembly points.

5. **Safety Operations Dashboard (Manager View)**:
   - Live venue capacity vs occupancy gauge and Fruin Level of Service (LOS) assessments.
   - **OpenCV WebCam Optical Telemetry Monitor & Wireless Mobile Camera**:
     - **📱 Wireless Smartphone Camera Pairing**: Scan the generated on-screen QR Code with any iPhone or Android phone to launch the full-screen **Mobile Optical AI Broadcaster**. The phone streams video frames and crowd telemetry in real time straight to the Event Manager dashboard!
     - **Rear / Back Camera Scanning**: Instant toggle between front camera and high-definition mobile rear camera (`facingMode: 'environment'`), perfect for security marshals scanning queues and concourses.
     - **Hardware Device Selection**: Automatically detects and switches between all physical webcams, mobile USB cams, Continuity Cameras, or DroidCam devices.
     - Frame-by-frame luminance extraction and Lucas-Kanade optical flow vector tracking.
     - Real-time head silhouette detection with confidence bounding boxes and privacy blur mode (zero facial identification stored).
     - Live thermal density heatmaps, optical velocity calculation ($m/s$), and one-click **"Push to Sector Telemetry"** into the venue map.
   - **Predictive Crowd Density & Place Capacity Analysis Engine**:
     - Timeline forecasting: *Current Live*, *+15 Mins*, *+30 Mins (Peak)*, and *+60 Mins (Dispersal)*.
     - Consequence modeling for physical compressive crush, velocity collapse, egress starvation, and thermal stress.
     - Dynamic what-if stress testers (+25% transit surge, 50% gate stoppage) and one-click proactive mitigations.
   - Automated bottleneck detection and triage queue with steward dispatch audit logs.

6. **Mobile Camera Broadcaster View (`?view=mobile-camera`)**:
   - Full-screen, touch-optimized camera viewfinder on mobile devices.
   - Real-time on-device AI person & silhouette detection with confidence tags.
   - Instant camera flip (Back / Front).
   - Live broadcast to desktop command center.

---

## 🚀 Running the Project Locally

### Prerequisites
- Node.js (v18 or newer)
- npm (v9 or newer)

### Installation & Launch
```bash
# 1. Install dependencies
npm install

# 2. Run the Vite development server
npm run dev
```
The application will start at `http://localhost:3000`.

### Production Build
```bash
# Type check and build optimized bundle
npm run build

# Preview production build locally
npm run preview
```

---

## 🧪 Demo Accounts & Simulation Modes

| Role | Demo Account | Capabilities |
| :--- | :--- | :--- |
| **Attendee** | `Maya Chen` (`maya.chen.attendee@example.com`) | Venue map, calm route pathfinding, nearby water/restrooms/first-aid, accessibility preferences. |
| **Safety Manager** | `Marcus Vance` (`marcus.vance@crowdsafe-eventcontrol.org`) | Full operations dashboard, active bottleneck queue, dispatching steward teams, threshold calibration. |

- **Telemetry Simulation**: Zone densities, flow rates, and arrivals subtly drift every 9 seconds to demonstrate dynamic monitoring. You can pause or resume this anytime via the live telemetry badge in the top navbar.
- **Privacy Notice**: Location processing is strictly client-side within the browser session; no personal identifiers or background telemetry are transmitted.

---

## 🔌 Connecting Real-World Telemetry & Integrations

For live production deployments:
1. **Sensor Telemetry Feeds**:
   - Stream overhead optical camera density figures via WebSockets to `/api/telemetry/zones`.
   - Gate turnstiles (NFC/RFID) publish inflow/outflow counters via MQTT or REST webhooks.
2. **Authentication**:
   - Connect Firebase Authentication or enterprise SSO for role-based steward dispatch logins.
3. **Emergency Broadcasts**:
   - Integrate Web Push API or SMS gateway for urgent safety announcements coordinated with local public safety authorities.
